import { useMemo, useState } from 'react';
import type { Employee } from '../../shared/types';
import { api } from '../api/client';
import { EmployeeFormModal } from '../components/employees/EmployeeFormModal';
import { AvatarIcon } from '../components/office/PixelAvatar';
import { IconArchive, IconChat, IconEdit, IconPlus, IconRestore, IconSearch, IconUsers } from '../components/ui/icons';
import { ActivityBadge, Button, ConfigBadge, ConfirmModal, cx, EmptyState, inputCls, Skeleton } from '../components/ui/ui';
import { openProfile, type Route } from '../lib/router';
import { useData } from '../state/DataContext';

type Filter = 'active' | 'archived' | 'all';

export function EmployeesPage({ route }: { route: Route }) {
  const { employees, desks, loading, reloadEmployees, toast, toastError } = useData();
  const [filter, setFilter] = useState<Filter>('active');
  const [q, setQ] = useState('');
  const [editing, setEditing] = useState<Employee | null>(null);
  const [adding, setAdding] = useState(false);
  const [archiving, setArchiving] = useState<Employee | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);

  const counts = { active: employees.filter((e) => !e.archived).length, archived: employees.filter((e) => e.archived).length, all: employees.length };
  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    return employees
      .filter((e) => (filter === 'all' ? true : filter === 'active' ? !e.archived : e.archived))
      .filter((e) => !term || `${e.name} ${e.role} ${e.description}`.toLowerCase().includes(term));
  }, [employees, filter, q]);

  async function setArchived(emp: Employee, archived: boolean) {
    setBusyId(emp.id);
    try {
      if (archived) await api.archiveEmployee(emp.id);
      else await api.restoreEmployee(emp.id);
      await reloadEmployees();
      toast(archived ? `${emp.name} diarsipkan.` : `${emp.name} aktif kembali.`);
      setArchiving(null);
    } catch (e) {
      toastError(e);
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="mx-auto max-w-[1240px] space-y-5 p-5 lg:p-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Karyawan AI</h1>
          <p className="text-sm text-slate-500">Tambah, edit, arsipkan, dan buka profil karyawan.</p>
        </div>
        <Button variant="primary" onClick={() => setAdding(true)}>
          <IconPlus size={16} /> Tambah karyawan
        </Button>
      </header>

      <div className="flex flex-wrap items-center gap-3">
        <div className="flex rounded-lg bg-white p-0.5 ring-1 ring-line" role="tablist">
          {(['active', 'archived', 'all'] as Filter[]).map((f) => (
            <button
              key={f}
              type="button"
              role="tab"
              aria-selected={filter === f}
              onClick={() => setFilter(f)}
              className={cx('rounded-md px-3 py-1.5 text-sm font-medium', filter === f ? 'bg-ink-900 text-white' : 'text-slate-600 hover:text-ink-900')}
            >
              {f === 'active' ? 'Aktif' : f === 'archived' ? 'Diarsipkan' : 'Semua'} <span className="opacity-60">{counts[f]}</span>
            </button>
          ))}
        </div>
        <div className="relative w-full max-w-xs">
          <IconSearch size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input className={cx(inputCls(), 'pl-9')} placeholder="Cari nama atau jabatan…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Cari karyawan" />
        </div>
      </div>

      {loading ? (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {[0, 1, 2].map((i) => <Skeleton key={i} className="h-44" />)}
        </div>
      ) : list.length === 0 ? (
        <EmptyState
          icon={<IconUsers size={28} />}
          title={q ? 'Tidak ada hasil' : filter === 'archived' ? 'Tidak ada karyawan diarsipkan' : 'Belum ada karyawan'}
          action={!q && filter !== 'archived' ? <Button variant="primary" onClick={() => setAdding(true)}><IconPlus size={16} /> Tambah karyawan</Button> : undefined}
        >
          {q ? `Tidak ada karyawan yang cocok dengan “${q}”.` : filter === 'archived' ? 'Karyawan yang diarsipkan akan muncul di sini.' : 'Tambahkan karyawan AI pertama Anda.'}
        </EmptyState>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3" data-testid="employee-list">
          {list.map((e) => {
            const desk = desks.find((d) => d.id === e.deskId);
            return (
              <article key={e.id} className={cx('flex flex-col rounded-2xl bg-white p-4 ring-1 ring-line', e.archived && 'opacity-75')} data-testid="employee-card">
                <div className="flex items-start gap-3">
                  <button type="button" onClick={() => openProfile(route, e.id)} aria-label={`Buka profil ${e.name}`}>
                    <AvatarIcon avatar={e.avatar} color={e.color} size={52} />
                  </button>
                  <div className="min-w-0 flex-1">
                    <button type="button" onClick={() => openProfile(route, e.id)} className="block max-w-full truncate text-left font-semibold hover:underline">
                      {e.name}
                    </button>
                    <div className="truncate text-sm text-slate-500">{e.role}</div>
                    <div className="mt-1.5 flex flex-wrap gap-1">
                      {e.archived ? (
                        <span className="rounded-full bg-slate-200 px-2 py-0.5 text-xs font-medium text-slate-600">Diarsipkan</span>
                      ) : (
                        <>
                          <ConfigBadge status={e.configStatus} />
                          <ActivityBadge status={e.activityStatus} />
                        </>
                      )}
                    </div>
                  </div>
                  <span className="mt-1 size-3 shrink-0 rounded-full ring-2 ring-white" style={{ background: e.color }} title="Warna identitas" />
                </div>
                <p className="mt-3 line-clamp-2 min-h-10 text-sm text-slate-600">{e.description || <span className="text-slate-400">Belum ada deskripsi.</span>}</p>
                <div className="mt-2 text-xs text-slate-500">{e.archived ? 'Tidak menempati meja' : desk ? desk.label : 'Area santai (tanpa meja)'}</div>
                <div className="mt-3 flex flex-wrap gap-1.5 border-t border-line pt-3">
                  <Button size="sm" onClick={() => openProfile(route, e.id, 'chat')} disabled={e.archived}><IconChat size={14} /> Chat</Button>
                  <Button size="sm" onClick={() => setEditing(e)}><IconEdit size={14} /> Edit</Button>
                  {e.archived ? (
                    <Button size="sm" className="ml-auto" loading={busyId === e.id} onClick={() => setArchived(e, false)}><IconRestore size={14} /> Aktifkan</Button>
                  ) : (
                    <Button size="sm" variant="ghost" className="ml-auto" onClick={() => setArchiving(e)}><IconArchive size={14} /> Arsipkan</Button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}

      <EmployeeFormModal open={adding} onClose={() => setAdding(false)} />
      <EmployeeFormModal open={!!editing} employee={editing} onClose={() => setEditing(null)} />
      <ConfirmModal
        open={!!archiving}
        title={`Arsipkan ${archiving?.name ?? ''}?`}
        message="Karyawan disembunyikan dari kantor dan mejanya dikosongkan. Percakapan dan tugas tetap tersimpan, dan Anda bisa mengaktifkannya kembali."
        confirmLabel="Arsipkan"
        busy={!!archiving && busyId === archiving.id}
        onConfirm={() => archiving && setArchived(archiving, true)}
        onClose={() => setArchiving(null)}
      />
    </div>
  );
}
