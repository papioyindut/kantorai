import { useEffect, useState, type FormEvent, type ReactNode } from 'react';
import { LIMITS, type SystemInfo } from '../../shared/types';
import { api } from '../api/client';
import { IconDownload, IconLock } from '../components/ui/icons';
import { Button, Callout, cx, Field, inputCls, Skeleton, SoonBadge } from '../components/ui/ui';
import { formatDateTime } from '../lib/labels';
import { useData } from '../state/DataContext';

function Card({ title, children, right }: { title: string; children: ReactNode; right?: ReactNode }) {
  return (
    <section className="rounded-2xl bg-white p-5 ring-1 ring-line">
      <div className="mb-3 flex items-center justify-between gap-2">
        <h2 className="font-semibold">{title}</h2>
        {right}
      </div>
      {children}
    </section>
  );
}

export function SettingsPage() {
  const { settings, setSettings, toast, toastError } = useData();
  const [name, setName] = useState('');
  const [nameErr, setNameErr] = useState<string | undefined>();
  const [saving, setSaving] = useState(false);
  const [demoBusy, setDemoBusy] = useState(false);
  const [info, setInfo] = useState<SystemInfo | null>(null);
  const [infoErr, setInfoErr] = useState<string | null>(null);

  useEffect(() => {
    if (settings) setName(settings.officeName);
  }, [settings]);
  useEffect(() => {
    api.system().then(setInfo).catch((e: Error) => setInfoErr(e.message));
  }, []);

  async function saveName(e: FormEvent) {
    e.preventDefault();
    const v = name.trim();
    if (!v) return setNameErr('Nama kantor wajib diisi.');
    if (v.length > LIMITS.officeName) return setNameErr(`Maksimal ${LIMITS.officeName} karakter.`);
    setNameErr(undefined);
    setSaving(true);
    try {
      setSettings(await api.updateSettings({ officeName: v }));
      toast('Nama kantor disimpan.');
    } catch (err) {
      toastError(err);
    } finally {
      setSaving(false);
    }
  }

  async function toggleDemo() {
    if (!settings) return;
    setDemoBusy(true);
    try {
      const s = await api.updateSettings({ demoMode: !settings.demoMode });
      setSettings(s);
      toast(s.demoMode ? 'Mode demo aktif. Balasan akan berlabel “Simulasi”.' : 'Mode demo dimatikan.');
    } catch (err) {
      toastError(err);
    } finally {
      setDemoBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl space-y-4 p-5 lg:p-6">
      <header>
        <h1 className="text-2xl font-bold tracking-tight">Pengaturan</h1>
        <p className="text-sm text-slate-500">Pengaturan kantor dan informasi penyimpanan lokal.</p>
      </header>

      <Card title="Kantor">
        {!settings ? (
          <Skeleton className="h-16" />
        ) : (
          <form onSubmit={saveName} className="flex items-end gap-2" noValidate>
            <div className="flex-1">
              <Field label="Nama kantor" htmlFor="office-name" error={nameErr} counter={`${name.length}/${LIMITS.officeName}`}>
                <input id="office-name" className={inputCls(nameErr)} value={name} maxLength={LIMITS.officeName} onChange={(e) => setName(e.target.value)} />
              </Field>
            </div>
            <Button type="submit" variant="primary" loading={saving} disabled={name.trim() === settings.officeName}>
              Simpan
            </Button>
          </form>
        )}
      </Card>

      <Card title="Mode demo">
        <div className="flex items-start justify-between gap-4">
          <p className="text-sm text-slate-600">
            Saat aktif, karyawan yang belum dikonfigurasi membalas dengan <b>balasan simulasi</b> berlabel “Simulasi”. Balasan ini dibuat dari template lokal — bukan dari
            model AI — dan tetap tersimpan di riwayat dengan label yang sama.
          </p>
          <button
            type="button"
            role="switch"
            aria-checked={!!settings?.demoMode}
            aria-label="Mode demo"
            disabled={!settings || demoBusy}
            onClick={toggleDemo}
            data-testid="demo-toggle"
            className={cx('relative h-6 w-11 shrink-0 rounded-full transition-colors disabled:opacity-50', settings?.demoMode ? 'bg-violet-600' : 'bg-slate-300')}
          >
            <span className={cx('absolute top-0.5 size-5 rounded-full bg-white shadow transition-all', settings?.demoMode ? 'left-[22px]' : 'left-0.5')} />
          </button>
        </div>
      </Card>

      <Card title="Integrasi AI" right={<SoonBadge />}>
        <p className="mb-3 text-sm text-slate-600">Provider model, workflow engine, tools, dan memori dikonfigurasi pada tahap berikutnya. Aplikasi tidak membutuhkan API key saat ini.</p>
        <div className="grid gap-2 sm:grid-cols-2">
          {['Provider model (OpenAI, Anthropic, lokal…)', 'Workflow engine', 'Tools & akses file', 'Memori jangka panjang'].map((l) => (
            <button key={l} type="button" disabled className="flex items-center gap-2 rounded-lg border border-dashed border-line px-3 py-2 text-left text-sm text-slate-400">
              <IconLock size={15} /> {l}
            </button>
          ))}
        </div>
        {info && (
          <p className="mt-3 text-xs text-slate-500">
            Adapter terdaftar: {info.providers.map((p) => `${p.label}${p.kind === 'mock' ? ' (mock)' : ''}`).join(', ')} · Workflow engine: {info.workflowEngines.map((w) => w.label).join(', ')}
          </p>
        )}
      </Card>

      <Card title="Penyimpanan lokal" right={<a href="/api/export" download className="inline-flex items-center gap-1 text-sm font-medium text-ink-700 hover:underline"><IconDownload size={15} /> Ekspor JSON</a>}>
        {infoErr && <Callout tone="warn">{infoErr}</Callout>}
        {!info && !infoErr ? (
          <Skeleton className="h-24" />
        ) : info ? (
          <dl className="grid grid-cols-[150px_1fr] gap-y-2 text-sm">
            <dt className="text-slate-500">File database</dt>
            <dd className="break-all font-mono text-xs" data-testid="db-path">{info.dbPath}</dd>
            <dt className="text-slate-500">Versi skema</dt>
            <dd>{info.schemaVersion}</dd>
            <dt className="text-slate-500">Data contoh dibuat</dt>
            <dd>{info.seededAt ? formatDateTime(info.seededAt) : '—'}</dd>
            <dt className="text-slate-500">Server</dt>
            <dd>{info.host}:{info.port} (hanya lokal) · Node {info.nodeVersion}</dd>
            <dt className="text-slate-500">Versi aplikasi</dt>
            <dd>{info.version}</dd>
          </dl>
        ) : null}
        <p className="mt-3 text-xs text-slate-500">Cadangkan data dengan menyalin file database saat aplikasi tidak berjalan. Lokasi bisa diubah dengan variabel lingkungan <code>VO_DATA_DIR</code>.</p>
      </Card>
    </div>
  );
}
