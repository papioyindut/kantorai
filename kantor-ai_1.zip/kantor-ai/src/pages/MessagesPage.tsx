import { useCallback, useEffect, useMemo, useState } from 'react';
import type { ConversationSummary } from '../../shared/types';
import { api } from '../api/client';
import { ChatPanel } from '../components/chat/ChatPanel';
import { AvatarIcon } from '../components/office/PixelAvatar';
import { IconChat, IconSearch } from '../components/ui/icons';
import { cx, EmptyState, inputCls, Skeleton, StatusDot } from '../components/ui/ui';
import { formatShort } from '../lib/labels';
import { buildHash, navigate, type Route } from '../lib/router';
import { useData } from '../state/DataContext';

export function MessagesPage({ route }: { route: Route }) {
  const { employees, loading, employeeById } = useData();
  const [summaries, setSummaries] = useState<ConversationSummary[] | null>(null);
  const [showArchived, setShowArchived] = useState(false);
  const [q, setQ] = useState('');
  const selectedId = route.segments[0] ?? null;

  const refresh = useCallback(() => {
    api.conversations().then(setSummaries).catch(() => setSummaries([]));
  }, []);
  useEffect(refresh, [refresh, employees.length]);

  const rows = useMemo(() => {
    const byEmp = new Map((summaries ?? []).map((s) => [s.employeeId, s]));
    const term = q.trim().toLowerCase();
    return employees
      .filter((e) => showArchived || !e.archived)
      .filter((e) => !term || `${e.name} ${e.role}`.toLowerCase().includes(term))
      .map((e) => ({ emp: e, s: byEmp.get(e.id) }))
      .sort((a, b) => (b.s?.updatedAt ?? '').localeCompare(a.s?.updatedAt ?? '') || a.emp.createdAt.localeCompare(b.emp.createdAt));
  }, [employees, summaries, q, showArchived]);

  const selected = employeeById(selectedId);

  return (
    <div className="flex h-full min-h-0">
      <aside className="flex w-80 shrink-0 flex-col border-r border-line bg-white">
        <div className="space-y-2 border-b border-line p-4">
          <h1 className="text-lg font-bold">Pesan</h1>
          <div className="relative">
            <IconSearch size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input className={cx(inputCls(), 'pl-9')} placeholder="Cari karyawan…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Cari percakapan" />
          </div>
          <label className="flex items-center gap-2 text-xs text-slate-500">
            <input type="checkbox" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} /> Tampilkan karyawan diarsipkan
          </label>
        </div>
        <ul className="thin-scroll flex-1 overflow-y-auto p-2" data-testid="conversation-list">
          {loading || !summaries ? (
            [0, 1, 2, 3].map((i) => <Skeleton key={i} className="mb-2 h-14" />)
          ) : rows.length === 0 ? (
            <li className="p-4 text-center text-sm text-slate-500">Tidak ada karyawan.</li>
          ) : (
            rows.map(({ emp, s }) => {
              const last = s?.lastMessage;
              const preview = last ? `${last.sender === 'user' ? 'Anda: ' : last.kind === 'simulation' ? '[Simulasi] ' : ''}${last.content}` : 'Belum ada pesan';
              return (
                <li key={emp.id}>
                  <button
                    type="button"
                    onClick={() => navigate(buildHash('messages', [emp.id]))}
                    data-employee-id={emp.id}
                    className={cx('flex w-full items-center gap-3 rounded-xl px-2.5 py-2 text-left transition', selectedId === emp.id ? 'bg-paper-2' : 'hover:bg-paper')}
                  >
                    <div className="relative">
                      <AvatarIcon avatar={emp.avatar} color={emp.color} size={40} />
                      <StatusDot status={emp.activityStatus} className="absolute -bottom-0.5 -right-0.5 ring-2 ring-white" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-baseline justify-between gap-2">
                        <span className="truncate text-sm font-semibold">{emp.name}</span>
                        {last && <span className="shrink-0 text-[11px] text-slate-400">{formatShort(last.createdAt)}</span>}
                      </div>
                      <div className={cx('truncate text-xs', last ? 'text-slate-500' : 'italic text-slate-400')}>{preview}</div>
                    </div>
                  </button>
                </li>
              );
            })
          )}
        </ul>
      </aside>
      <section className="min-w-0 flex-1 bg-paper">
        {selected ? (
          <ChatPanel key={selected.id} employee={selected} onMessagesChanged={refresh} />
        ) : (
          <div className="flex h-full items-center justify-center p-8">
            <EmptyState icon={<IconChat size={32} />} title="Pilih percakapan">
              Pilih karyawan AI di kiri, atau klik avatar di kantor untuk membuka percakapannya.
            </EmptyState>
          </div>
        )}
      </section>
    </div>
  );
}
