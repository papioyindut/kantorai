import { useEffect, useMemo, useRef, useState, type CSSProperties } from 'react';
import type { Desk, Employee } from '../../shared/types';
import { MAP_H, MAP_W } from '../../shared/officeLayout';
import { api } from '../api/client';
import { EmployeeFormModal } from '../components/employees/EmployeeFormModal';
import { OfficeScene, type SceneAnchor } from '../components/office/OfficeScene';
import { AvatarIcon } from '../components/office/PixelAvatar';
import { IconChat, IconMove, IconPlus, IconUsers, IconX } from '../components/ui/icons';
import { ActivityBadge, Button, Callout, ConfigBadge, cx, EmptyState, Skeleton, StatusDot } from '../components/ui/ui';
import { ACTIVITY_COLOR, ACTIVITY_LABEL } from '../lib/labels';
import { openProfile, type Route } from '../lib/router';
import { useData } from '../state/DataContext';

type Pop =
  | { type: 'employee'; emp: Employee; anchor: SceneAnchor }
  | { type: 'desk'; desk: Desk; anchor: SceneAnchor }
  | { type: 'pickDesk'; emp: Employee; anchor: SceneAnchor };

function popStyle(a: SceneAnchor): CSSProperties {
  const left = (a.x / MAP_W) * 100;
  const below = a.y < 150;
  const top = ((below ? a.y + 92 : a.y - 12) / MAP_H) * 100;
  const tx = a.x > MAP_W * 0.78 ? '-90%' : a.x < MAP_W * 0.18 ? '-10%' : '-50%';
  return { left: `${left}%`, top: `${top}%`, transform: `translate(${tx}, ${below ? '0' : '-100%'})` };
}

export function OfficePage({ route }: { route: Route }) {
  const { loading, loadError, employees, desks, settings, reload, setEmployees, setDesks, toast, toastError, employeeById } = useData();
  const [layoutMode, setLayoutMode] = useState(false);
  const [pop, setPop] = useState<Pop | null>(null);
  const [busy, setBusy] = useState(false);
  const [addOpen, setAddOpen] = useState(false);
  const wrapRef = useRef<HTMLDivElement>(null);

  const active = useMemo(() => employees.filter((e) => !e.archived), [employees]);
  const seated = new Set(desks.map((d) => d.employeeId).filter(Boolean));
  const unseated = active.filter((e) => !seated.has(e.id));
  const freeDesks = desks.filter((d) => !d.employeeId);

  useEffect(() => {
    if (!pop) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && setPop(null);
    const onDown = (e: MouseEvent) => {
      const t = e.target as Element;
      if (!t.closest('[data-popover]') && !t.closest('.office-hit')) setPop(null);
    };
    window.addEventListener('keydown', onKey);
    window.addEventListener('mousedown', onDown);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('mousedown', onDown);
    };
  }, [pop]);

  useEffect(() => setPop(null), [layoutMode]);

  async function assign(empId: string, deskId: string | null) {
    setBusy(true);
    try {
      const res = await api.assignDesk(empId, deskId);
      setEmployees(res.employees);
      setDesks(res.desks);
      const emp = res.employees.find((e) => e.id === empId);
      toast(deskId ? `${emp?.name} ditempatkan di ${res.desks.find((d) => d.id === deskId)?.label}.` : `${emp?.name} pindah ke area santai.`);
      setPop(null);
    } catch (e) {
      toastError(e);
    } finally {
      setBusy(false);
    }
  }

  if (loadError)
    return (
      <div className="p-8">
        <Callout tone="warn" title="Tidak dapat memuat kantor" action={<Button onClick={() => void reload()}>Coba lagi</Button>}>
          {loadError}
        </Callout>
      </div>
    );

  return (
    <div className="mx-auto flex max-w-[1240px] flex-col gap-4 p-5 lg:p-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{settings?.officeName ?? 'Kantor'}</h1>
          <p className="text-sm text-slate-500">
            {active.length} karyawan AI · {desks.length - freeDesks.length}/{desks.length} meja terisi
            {unseated.length > 0 && ` · ${unseated.length} di area santai`}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant={layoutMode ? 'primary' : 'secondary'} onClick={() => setLayoutMode((v) => !v)} aria-pressed={layoutMode}>
            <IconMove size={16} /> {layoutMode ? 'Selesai mengatur' : 'Atur meja'}
          </Button>
          <Button variant="primary" onClick={() => setAddOpen(true)}>
            <IconPlus size={16} /> Karyawan
          </Button>
        </div>
      </header>

      {layoutMode && (
        <Callout title="Mode atur meja">
          Klik meja untuk menempatkan atau memindahkan karyawan. Klik karyawan di area santai untuk memilihkan meja. Posisi tersimpan otomatis.
        </Callout>
      )}

      <div ref={wrapRef} className="relative overflow-hidden rounded-2xl bg-ink-900 shadow-lg ring-4 ring-ink-900" style={{ aspectRatio: `${MAP_W} / ${MAP_H}` }} data-testid="office-scene">
        {loading ? (
          <Skeleton className="h-full w-full bg-ink-800" />
        ) : (
          <OfficeScene
            officeName={settings?.officeName ?? 'Kantor'}
            employees={active}
            desks={desks}
            layoutMode={layoutMode}
            selectedId={pop && pop.type !== 'desk' ? pop.emp.id : null}
            selectedDeskId={pop?.type === 'desk' ? pop.desk.id : null}
            onEmployeeClick={(emp, anchor) => setPop(layoutMode ? { type: 'pickDesk', emp, anchor } : { type: 'employee', emp, anchor })}
            onDeskClick={(desk, anchor) => setPop({ type: 'desk', desk, anchor })}
          />
        )}

        {pop && (
          <div data-popover className="vo-fade-in absolute z-10 w-64 rounded-xl bg-white p-3 text-ink-900 shadow-2xl ring-1 ring-black/10" style={popStyle(pop.anchor)}>
            <button type="button" onClick={() => setPop(null)} className="absolute right-2 top-2 rounded p-0.5 text-slate-400 hover:bg-slate-100" aria-label="Tutup">
              <IconX size={14} />
            </button>

            {pop.type === 'employee' && (() => {
              const emp = employeeById(pop.emp.id) ?? pop.emp;
              return (
                <div data-testid="employee-popover">
                  <div className="flex items-center gap-3 pr-5">
                    <AvatarIcon avatar={emp.avatar} color={emp.color} size={44} />
                    <div className="min-w-0">
                      <div className="truncate font-semibold">{emp.name}</div>
                      <div className="truncate text-xs text-slate-500">{emp.role}</div>
                    </div>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1">
                    <ConfigBadge status={emp.configStatus} />
                    <ActivityBadge status={emp.activityStatus} />
                  </div>
                  {emp.configStatus !== 'ready' && <p className="mt-2 text-xs text-slate-500">Runtime AI belum terhubung, jadi belum bisa mengerjakan tugas.</p>}
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <Button size="sm" onClick={() => { setPop(null); openProfile(route, emp.id, 'overview'); }}>Profil</Button>
                    <Button size="sm" variant="primary" onClick={() => { setPop(null); openProfile(route, emp.id, 'chat'); }}>
                      <IconChat size={14} /> Chat
                    </Button>
                  </div>
                </div>
              );
            })()}

            {pop.type === 'desk' && (() => {
              const desk = desks.find((d) => d.id === pop.desk.id) ?? pop.desk;
              const occ = employeeById(desk.employeeId);
              return (
                <div data-testid="desk-popover">
                  <div className="text-sm font-semibold">{desk.label}</div>
                  <div className="mb-2 text-xs text-slate-500">{occ ? `Ditempati ${occ.name}` : 'Kosong — pilih karyawan'}</div>
                  {active.length === 0 ? (
                    <p className="text-xs text-slate-500">Belum ada karyawan aktif.</p>
                  ) : (
                    <ul className="thin-scroll max-h-52 space-y-0.5 overflow-y-auto">
                      {active.map((e) => {
                        const cur = desks.find((d) => d.employeeId === e.id);
                        const here = cur?.id === desk.id;
                        return (
                          <li key={e.id}>
                            <button
                              type="button"
                              disabled={busy || here}
                              onClick={() => assign(e.id, desk.id)}
                              className={cx('flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-sm hover:bg-paper-2 disabled:cursor-default', here && 'bg-paper-2')}
                            >
                              <AvatarIcon avatar={e.avatar} color={e.color} size={22} />
                              <span className="min-w-0 flex-1 truncate">{e.name}</span>
                              <span className="text-[11px] text-slate-400">{here ? 'di sini' : cur ? cur.label : 'santai'}</span>
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}
                  {occ && (
                    <div className="mt-2 flex gap-2 border-t border-line pt-2">
                      <Button size="sm" className="flex-1" disabled={busy} onClick={() => assign(occ.id, null)}>Kosongkan</Button>
                      {!layoutMode && (
                        <Button size="sm" variant="primary" className="flex-1" onClick={() => { setPop(null); openProfile(route, occ.id); }}>Profil</Button>
                      )}
                    </div>
                  )}
                </div>
              );
            })()}

            {pop.type === 'pickDesk' && (
              <div data-testid="pickdesk-popover">
                <div className="pr-5 text-sm font-semibold">Pilih meja untuk {pop.emp.name}</div>
                {freeDesks.length === 0 ? (
                  <p className="mt-2 text-xs text-slate-500">Semua meja terisi. Klik meja yang terisi untuk menukar penghuninya.</p>
                ) : (
                  <div className="mt-2 grid grid-cols-3 gap-1.5">
                    {freeDesks.map((d) => (
                      <Button key={d.id} size="sm" disabled={busy} onClick={() => assign(pop.emp.id, d.id)}>
                        {d.label.replace('Meja ', 'M')}
                      </Button>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Roster & legenda */}
      <div className="grid gap-4 lg:grid-cols-[1fr_auto]">
        <div className="rounded-2xl bg-white p-4 ring-1 ring-line">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-semibold">Tim hari ini</h2>
            <a href="#/employees" className="text-xs font-medium text-slate-500 hover:text-ink-900">Kelola karyawan →</a>
          </div>
          {loading ? (
            <Skeleton className="h-10" />
          ) : active.length === 0 ? (
            <EmptyState icon={<IconUsers size={28} />} title="Kantor masih kosong" action={<Button variant="primary" onClick={() => setAddOpen(true)}><IconPlus size={16} /> Tambah karyawan AI</Button>}>
              Tambahkan karyawan AI pertama Anda, lalu tempatkan di meja.
            </EmptyState>
          ) : (
            <div className="flex flex-wrap gap-2">
              {active.map((e) => (
                <button
                  key={e.id}
                  type="button"
                  onClick={() => openProfile(route, e.id)}
                  className="flex items-center gap-2 rounded-full bg-paper py-1 pl-1 pr-3 text-sm ring-1 ring-line transition hover:bg-paper-2"
                >
                  <AvatarIcon avatar={e.avatar} color={e.color} size={26} />
                  <span className="font-medium">{e.name}</span>
                  <StatusDot status={e.activityStatus} />
                </button>
              ))}
            </div>
          )}
        </div>
        <div className="rounded-2xl bg-white p-4 text-xs ring-1 ring-line">
          <h2 className="mb-2 text-sm font-semibold">Legenda status</h2>
          <ul className="grid grid-cols-2 gap-x-4 gap-y-1.5 lg:grid-cols-1">
            {(['idle', 'working', 'waiting', 'error', 'offline'] as const).map((s) => (
              <li key={s} className="flex items-center gap-2">
                <span className="size-2 rounded-full" style={{ background: ACTIVITY_COLOR[s] }} /> {ACTIVITY_LABEL[s]}
              </li>
            ))}
          </ul>
          <p className="mt-2 max-w-[200px] text-slate-500">AI yang belum dikonfigurasi selalu tampil Offline.</p>
        </div>
      </div>

      <EmployeeFormModal open={addOpen} onClose={() => setAddOpen(false)} onSaved={(e) => openProfile(route, e.id)} />
    </div>
  );
}
