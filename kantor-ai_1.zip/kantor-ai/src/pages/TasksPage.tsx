import { useEffect, useMemo, useState } from 'react';
import { TASK_PRIORITIES, TASK_STATUSES, type Task, type TaskPriority, type TaskStatus } from '../../shared/types';
import { api } from '../api/client';
import { TaskCard } from '../components/tasks/TaskCard';
import { TaskModal } from '../components/tasks/TaskModal';
import { IconPlus } from '../components/ui/icons';
import { Button, Callout, cx, inputCls, Skeleton } from '../components/ui/ui';
import { PRIORITY_LABEL, TASK_STATUS_ACCENT, TASK_STATUS_LABEL } from '../lib/labels';
import { useData } from '../state/DataContext';

export function TasksPage() {
  const { employees, taskRevision, bumpTasks, toastError } = useData();
  const [tasks, setTasks] = useState<Task[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [assignee, setAssignee] = useState('');
  const [priority, setPriority] = useState<'' | TaskPriority>('');
  const [creating, setCreating] = useState<TaskStatus | null>(null);
  const [editing, setEditing] = useState<Task | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [overCol, setOverCol] = useState<TaskStatus | null>(null);

  useEffect(() => {
    setError(null);
    api.tasks().then(setTasks).catch((e: Error) => setError(e.message));
  }, [taskRevision]);

  const filtered = useMemo(
    () =>
      (tasks ?? []).filter(
        (t) => (!assignee || (assignee === '__none' ? !t.assigneeId : t.assigneeId === assignee)) && (!priority || t.priority === priority),
      ),
    [tasks, assignee, priority],
  );

  async function moveTo(taskId: string, status: TaskStatus) {
    const t = tasks?.find((x) => x.id === taskId);
    if (!t || t.status === status) return;
    setTasks((list) => list?.map((x) => (x.id === taskId ? { ...x, status } : x)) ?? null); // optimistis
    try {
      await api.updateTask(taskId, { status });
      bumpTasks();
    } catch (e) {
      toastError(e);
      bumpTasks();
    }
  }

  return (
    <div className="flex h-full min-h-0 flex-col gap-4 p-5 lg:p-6">
      <header className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Tugas</h1>
          <p className="text-sm text-slate-500">Seret kartu antar kolom atau buka detail untuk mengubah tugas.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select aria-label="Filter karyawan" className={cx(inputCls(), '!w-48')} value={assignee} onChange={(e) => setAssignee(e.target.value)}>
            <option value="">Semua karyawan</option>
            <option value="__none">Belum ditugaskan</option>
            {employees.map((e) => (
              <option key={e.id} value={e.id}>{e.name}{e.archived ? ' (diarsipkan)' : ''}</option>
            ))}
          </select>
          <select aria-label="Filter prioritas" className={cx(inputCls(), '!w-40')} value={priority} onChange={(e) => setPriority(e.target.value as '' | TaskPriority)}>
            <option value="">Semua prioritas</option>
            {TASK_PRIORITIES.map((p) => <option key={p} value={p}>{PRIORITY_LABEL[p]}</option>)}
          </select>
          <Button variant="primary" onClick={() => setCreating('backlog')}>
            <IconPlus size={16} /> Tugas baru
          </Button>
        </div>
      </header>

      <Callout>Tahap ini: tugas dikelola manual. Menugaskan tugas ke karyawan AI hanya mencatat penugasan — belum menjalankan workflow.</Callout>
      {error && <Callout tone="warn" title="Gagal memuat tugas">{error}</Callout>}

      <div className="thin-scroll grid min-h-0 flex-1 auto-cols-[minmax(200px,1fr)] grid-flow-col gap-3 overflow-x-auto pb-2" data-testid="task-board">
        {TASK_STATUSES.map((s) => {
          const col = filtered.filter((t) => t.status === s);
          return (
            <section
              key={s}
              data-status={s}
              onDragOver={(e) => {
                e.preventDefault();
                setOverCol(s);
              }}
              onDragLeave={() => setOverCol((c) => (c === s ? null : c))}
              onDrop={(e) => {
                e.preventDefault();
                const id = e.dataTransfer.getData('text/plain');
                setOverCol(null);
                setDragId(null);
                if (id) void moveTo(id, s);
              }}
              className={cx('flex min-h-0 flex-col rounded-2xl bg-paper-2/70 ring-1 ring-line transition', overCol === s && 'bg-amber-50 ring-2 ring-brand')}
            >
              <div className="flex items-center justify-between px-3 pt-3 pb-2">
                <div className="flex items-center gap-2 text-sm font-semibold">
                  <span className="size-2.5 rounded-full" style={{ background: TASK_STATUS_ACCENT[s] }} />
                  {TASK_STATUS_LABEL[s]}
                  <span className="rounded-full bg-white px-1.5 text-xs font-medium text-slate-500 ring-1 ring-line">{col.length}</span>
                </div>
                <button type="button" onClick={() => setCreating(s)} className="rounded-md p-1 text-slate-500 hover:bg-white" aria-label={`Tambah tugas ke ${TASK_STATUS_LABEL[s]}`}>
                  <IconPlus size={16} />
                </button>
              </div>
              <div className="thin-scroll min-h-24 flex-1 space-y-2 overflow-y-auto px-3 pb-3">
                {!tasks && !error ? (
                  <Skeleton className="h-20" />
                ) : col.length === 0 ? (
                  <div className="rounded-xl border border-dashed border-line px-3 py-6 text-center text-xs text-slate-400">Kosong</div>
                ) : (
                  col.map((t) => (
                    <TaskCard
                      key={t.id}
                      task={t}
                      draggable
                      dragging={dragId === t.id}
                      onDragStart={(e) => {
                        e.dataTransfer.setData('text/plain', t.id);
                        e.dataTransfer.effectAllowed = 'move';
                        setDragId(t.id);
                      }}
                      onOpen={() => setEditing(t)}
                    />
                  ))
                )}
              </div>
            </section>
          );
        })}
      </div>

      <TaskModal open={!!creating} onClose={() => setCreating(null)} defaults={{ status: creating ?? 'backlog', assigneeId: assignee && assignee !== '__none' ? assignee : '' }} />
      <TaskModal open={!!editing} task={editing} onClose={() => setEditing(null)} />
    </div>
  );
}
