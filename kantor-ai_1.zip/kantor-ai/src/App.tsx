import type { ReactNode } from 'react';
import { EmployeeProfileDrawer } from './components/employees/EmployeeProfile';
import { IconChat, IconOffice, IconSettings, IconTasks, IconUsers } from './components/ui/icons';
import { cx, Toasts } from './components/ui/ui';
import { buildHash, useRoute, type Section } from './lib/router';
import { EmployeesPage } from './pages/EmployeesPage';
import { MessagesPage } from './pages/MessagesPage';
import { OfficePage } from './pages/OfficePage';
import { SettingsPage } from './pages/SettingsPage';
import { TasksPage } from './pages/TasksPage';
import { useData } from './state/DataContext';

const NAV: { id: Section; label: string; icon: ReactNode }[] = [
  { id: 'office', label: 'Office', icon: <IconOffice /> },
  { id: 'employees', label: 'Employees', icon: <IconUsers /> },
  { id: 'messages', label: 'Messages', icon: <IconChat /> },
  { id: 'tasks', label: 'Tasks', icon: <IconTasks /> },
  { id: 'settings', label: 'Settings', icon: <IconSettings /> },
];

const NAV_HINT: Record<Section, string> = {
  office: 'Kantor',
  employees: 'Karyawan',
  messages: 'Pesan',
  tasks: 'Tugas',
  settings: 'Pengaturan',
};

function Logo() {
  return (
    <svg width="30" height="30" viewBox="0 0 16 16" shapeRendering="crispEdges" aria-hidden>
      <rect width="16" height="16" rx="3" fill="#f4b740" />
      <rect x="3" y="4" width="10" height="9" fill="#1b2036" />
      <rect x="4" y="5" width="2" height="2" fill="#f4b740" />
      <rect x="7" y="5" width="2" height="2" fill="#5ee0c0" />
      <rect x="10" y="5" width="2" height="2" fill="#f4b740" />
      <rect x="4" y="8" width="2" height="2" fill="#5ee0c0" />
      <rect x="10" y="8" width="2" height="2" fill="#f4b740" />
      <rect x="7" y="9" width="2" height="4" fill="#f4b740" />
    </svg>
  );
}

export default function App() {
  const route = useRoute();
  const { settings, employees } = useData();
  const activeCount = employees.filter((e) => !e.archived).length;

  return (
    <div className="flex h-full min-h-0">
      <nav className="flex w-56 shrink-0 flex-col bg-ink-900 text-slate-300" aria-label="Navigasi utama">
        <div className="flex items-center gap-2.5 px-4 py-4">
          <Logo />
          <div className="min-w-0">
            <div className="truncate text-sm font-bold text-white">Kantor AI</div>
            <div className="truncate text-[11px] text-slate-400">{settings?.officeName ?? 'Memuat…'}</div>
          </div>
        </div>
        <ul className="mt-2 space-y-0.5 px-2">
          {NAV.map((n) => {
            const active = route.section === n.id;
            return (
              <li key={n.id}>
                <a
                  href={buildHash(n.id)}
                  aria-current={active ? 'page' : undefined}
                  className={cx(
                    'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                    active ? 'bg-white/10 text-white' : 'hover:bg-white/5 hover:text-white',
                  )}
                >
                  <span className={active ? 'text-brand' : 'text-slate-400'}>{n.icon}</span>
                  <span className="flex-1">{n.label}</span>
                  <span className="text-[10px] font-normal text-slate-500">{NAV_HINT[n.id]}</span>
                </a>
              </li>
            );
          })}
        </ul>
        <div className="mt-auto space-y-2 p-4 text-[11px] text-slate-400">
          <div className="rounded-lg bg-white/5 p-3">
            <div className="mb-1 font-semibold text-slate-200">Tahap 1 · Fondasi</div>
            {activeCount} karyawan aktif. Model & workflow AI belum disetup.
            {settings?.demoMode && <div className="mt-1.5 font-semibold text-violet-300">Mode demo aktif</div>}
          </div>
          <div>Berjalan lokal · tanpa API key</div>
        </div>
      </nav>

      <main className="thin-scroll min-w-0 flex-1 overflow-y-auto">
        {route.section === 'office' && <OfficePage route={route} />}
        {route.section === 'employees' && <EmployeesPage route={route} />}
        {route.section === 'messages' && <MessagesPage route={route} />}
        {route.section === 'tasks' && <TasksPage />}
        {route.section === 'settings' && <SettingsPage />}
      </main>

      <EmployeeProfileDrawer route={route} />
      <Toasts />
    </div>
  );
}
