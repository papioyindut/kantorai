import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type { AppSettings, Desk, Employee } from '../../shared/types';
import { api, ApiError } from '../api/client';

export interface Toast {
  id: number;
  kind: 'success' | 'error' | 'info';
  text: string;
}

interface DataState {
  loading: boolean;
  loadError: string | null;
  employees: Employee[];
  desks: Desk[];
  settings: AppSettings | null;
  /** Revisi tugas — naik setiap kali tugas berubah agar daftar terkait memuat ulang. */
  taskRevision: number;
  reload: () => Promise<void>;
  reloadEmployees: () => Promise<void>;
  setEmployees: (e: Employee[]) => void;
  setDesks: (d: Desk[]) => void;
  upsertEmployee: (e: Employee) => void;
  setSettings: (s: AppSettings) => void;
  bumpTasks: () => void;
  toasts: Toast[];
  toast: (text: string, kind?: Toast['kind']) => void;
  toastError: (err: unknown) => void;
  dismissToast: (id: number) => void;
  employeeById: (id: string | null | undefined) => Employee | undefined;
}

const Ctx = createContext<DataState | null>(null);

export function DataProvider({ children }: { children: ReactNode }) {
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [desks, setDesks] = useState<Desk[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);
  const [taskRevision, setTaskRevision] = useState(0);
  const [toasts, setToasts] = useState<Toast[]>([]);
  const seq = useRef(0);

  const dismissToast = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const toast = useCallback(
    (text: string, kind: Toast['kind'] = 'success') => {
      const id = ++seq.current;
      setToasts((t) => [...t.slice(-3), { id, kind, text }]);
      window.setTimeout(() => dismissToast(id), kind === 'error' ? 6000 : 3200);
    },
    [dismissToast],
  );
  const toastError = useCallback(
    (err: unknown) => toast(err instanceof ApiError || err instanceof Error ? err.message : 'Terjadi kesalahan.', 'error'),
    [toast],
  );

  const reload = useCallback(async () => {
    setLoadError(null);
    try {
      const [e, d, s] = await Promise.all([api.employees(), api.desks(), api.settings()]);
      setEmployees(e);
      setDesks(d);
      setSettings(s);
    } catch (err) {
      setLoadError(err instanceof Error ? err.message : 'Gagal memuat data.');
    } finally {
      setLoading(false);
    }
  }, []);

  const reloadEmployees = useCallback(async () => {
    try {
      const [e, d] = await Promise.all([api.employees(), api.desks()]);
      setEmployees(e);
      setDesks(d);
    } catch (err) {
      toastError(err);
    }
  }, [toastError]);

  const upsertEmployee = useCallback((emp: Employee) => {
    setEmployees((list) => (list.some((x) => x.id === emp.id) ? list.map((x) => (x.id === emp.id ? emp : x)) : [...list, emp]));
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  const value = useMemo<DataState>(
    () => ({
      loading,
      loadError,
      employees,
      desks,
      settings,
      taskRevision,
      reload,
      reloadEmployees,
      setEmployees,
      setDesks,
      upsertEmployee,
      setSettings,
      bumpTasks: () => setTaskRevision((r) => r + 1),
      toasts,
      toast,
      toastError,
      dismissToast,
      employeeById: (id) => (id ? employees.find((e) => e.id === id) : undefined),
    }),
    [loading, loadError, employees, desks, settings, taskRevision, reload, reloadEmployees, upsertEmployee, toasts, toast, toastError, dismissToast],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useData(): DataState {
  const v = useContext(Ctx);
  if (!v) throw new Error('useData harus di dalam DataProvider');
  return v;
}
