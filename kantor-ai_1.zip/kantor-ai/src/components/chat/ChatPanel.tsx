import { useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from 'react';
import { LIMITS, type Employee, type Message } from '../../../shared/types';
import { api } from '../../api/client';
import { buildHash } from '../../lib/router';
import { formatDateTime, formatShort } from '../../lib/labels';
import { useData } from '../../state/DataContext';
import { AvatarIcon } from '../office/PixelAvatar';
import { IconSend } from '../ui/icons';
import { ActivityBadge, Button, Callout, ConfigBadge, cx, Skeleton, Spinner } from '../ui/ui';

export function ChatPanel({ employee, compact, onMessagesChanged }: { employee: Employee; compact?: boolean; onMessagesChanged?: () => void }) {
  const { settings, toastError } = useData();
  const [messages, setMessages] = useState<Message[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [draft, setDraft] = useState('');
  const [sending, setSending] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    let alive = true;
    setMessages(null);
    setError(null);
    setNotice(null);
    api
      .messages(employee.id)
      .then((m) => alive && setMessages(m))
      .catch((e: Error) => alive && setError(e.message));
    return () => {
      alive = false;
    };
  }, [employee.id]);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight; // hanya container chat, bukan halaman
  }, [messages, sending]);

  async function send(e?: FormEvent) {
    e?.preventDefault();
    const content = draft.trim();
    if (!content || sending) return;
    if (content.length > LIMITS.message) return;
    setSending(true);
    setNotice(null);
    try {
      const res = await api.sendMessage(employee.id, content);
      setDraft('');
      setMessages((m) => [...(m ?? []), res.userMessage, ...(res.reply ? [res.reply] : [])]);
      setNotice(res.notice);
      onMessagesChanged?.();
    } catch (err) {
      toastError(err);
    } finally {
      setSending(false);
      inputRef.current?.focus();
    }
  }

  function onKeyDown(e: KeyboardEvent<HTMLTextAreaElement>) {
    if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      void send();
    }
  }

  const demo = settings?.demoMode ?? false;
  const unconfigured = employee.configStatus !== 'ready';
  const tooLong = draft.length > LIMITS.message;

  return (
    <div className="flex h-full min-h-0 flex-col" data-testid="chat-panel" data-employee-id={employee.id}>
      {!compact && (
        <div className="flex items-center gap-3 border-b border-line bg-white px-5 py-3">
          <AvatarIcon avatar={employee.avatar} color={employee.color} size={40} />
          <div className="min-w-0 flex-1">
            <div className="truncate font-semibold">{employee.name}</div>
            <div className="truncate text-xs text-slate-500">{employee.role}</div>
          </div>
          <ActivityBadge status={employee.activityStatus} />
          <ConfigBadge status={employee.configStatus} />
        </div>
      )}

      {unconfigured && (
        <div className="px-4 pt-3">
          <Callout
            tone="warn"
            title="AI belum dikonfigurasi"
            action={
              !demo ? (
                <a href={buildHash('settings')} className="shrink-0 text-xs font-semibold text-amber-900 underline underline-offset-2">
                  Mode demo
                </a>
              ) : undefined
            }
          >
            {demo
              ? 'Mode demo aktif: balasan yang muncul adalah SIMULASI, bukan dari model AI.'
              : 'Pesan Anda disimpan, tetapi belum ada model yang membalas. Model & workflow disetup pada tahap berikutnya.'}
          </Callout>
        </div>
      )}

      <div ref={scrollRef} className="thin-scroll min-h-0 flex-1 space-y-3 overflow-y-auto px-4 py-4" aria-live="polite">
        {error && <Callout tone="warn" title="Gagal memuat pesan">{error}</Callout>}
        {!messages && !error && (
          <div className="space-y-3">
            <Skeleton className="h-10 w-2/3" />
            <Skeleton className="ml-auto h-10 w-1/2" />
            <Skeleton className="h-10 w-3/5" />
          </div>
        )}
        {messages && messages.length === 0 && (
          <div className="flex flex-col items-center gap-2 py-10 text-center">
            <AvatarIcon avatar={employee.avatar} color={employee.color} size={56} />
            <div className="font-semibold">Mulai percakapan dengan {employee.name}</div>
            <div className="max-w-xs text-sm text-slate-500">Riwayat percakapan disimpan secara lokal dan tetap ada setelah aplikasi dibuka ulang.</div>
          </div>
        )}
        {messages?.map((m) => <Bubble key={m.id} m={m} employee={employee} />)}
        {sending && (
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Spinner className="size-3" /> Mengirim…
          </div>
        )}
        {notice && !sending && (
          <div className="mx-auto max-w-md rounded-lg bg-slate-100 px-3 py-2 text-center text-xs text-slate-600" data-testid="chat-notice">
            {notice}
          </div>
        )}
      </div>

      <form onSubmit={send} className="border-t border-line bg-white p-3">
        {employee.archived ? (
          <div className="text-center text-sm text-slate-500">Karyawan diarsipkan. Aktifkan kembali untuk mengirim pesan.</div>
        ) : (
          <div className="flex items-end gap-2">
            <textarea
              ref={inputRef}
              rows={1}
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              onKeyDown={onKeyDown}
              placeholder={`Tulis pesan untuk ${employee.name}…`}
              aria-label="Pesan"
              className={cx(
                'max-h-32 min-h-10 flex-1 resize-none rounded-xl border bg-paper/50 px-3 py-2 text-sm focus:outline-none focus:ring-2',
                tooLong ? 'border-red-400 focus:ring-red-200' : 'border-line focus:ring-brand/40',
              )}
            />
            <Button variant="primary" type="submit" disabled={!draft.trim() || tooLong} loading={sending} className="h-10" aria-label="Kirim">
              <IconSend size={16} />
              Kirim
            </Button>
          </div>
        )}
        {tooLong && <p className="mt-1 text-xs text-red-600">Pesan maksimal {LIMITS.message} karakter.</p>}
      </form>
    </div>
  );
}

function Bubble({ m, employee }: { m: Message; employee: Employee }) {
  const mine = m.sender === 'user';
  const sim = m.kind === 'simulation';
  return (
    <div className={cx('flex gap-2', mine ? 'justify-end' : 'justify-start')} data-testid="message" data-kind={m.kind} data-sender={m.sender}>
      {!mine && <AvatarIcon avatar={employee.avatar} color={employee.color} size={28} className="mt-0.5 shrink-0" />}
      <div className={cx('max-w-[78%]', mine && 'items-end')}>
        {sim && (
          <div className="mb-1 inline-flex items-center gap-1 rounded bg-violet-100 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-violet-700">
            Simulasi · bukan model AI
          </div>
        )}
        <div
          className={cx(
            'whitespace-pre-wrap break-words rounded-2xl px-3.5 py-2 text-sm leading-relaxed',
            mine && 'rounded-br-md bg-ink-900 text-white',
            !mine && !sim && 'rounded-bl-md bg-white ring-1 ring-line',
            sim && 'rounded-bl-md border border-dashed border-violet-300 bg-violet-50/60 text-ink-800',
          )}
        >
          {m.content}
        </div>
        <div className={cx('mt-0.5 text-[11px] text-slate-400', mine && 'text-right')} title={formatDateTime(m.createdAt)}>
          {formatShort(m.createdAt)}
        </div>
      </div>
    </div>
  );
}
