// Sprite karakter pixel art buatan sendiri, dirender sebagai <rect> SVG.
// Grid 16 kolom; 1 "piksel" = P unit SVG. Pose 'sit' (badan atas) atau 'stand' (seluruh badan).
import type { ActivityStatus, AvatarConfig } from '../../../shared/types';

export const P = 2;
const OUTLINE = '#1d1b2c';
const PANTS = '#2e3348';

type R = [number, number, number, number, string]; // x, y, w, h (grid), fill

function shade(hex: string, amt: number) {
  const n = parseInt(hex.slice(1), 16);
  const c = (v: number) => Math.max(0, Math.min(255, Math.round(v + amt * 255)));
  const r = c((n >> 16) & 255), g = c((n >> 8) & 255), b = c(n & 255);
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}

function hairBack(a: AvatarConfig): R[] {
  const h = a.hairColor;
  if (a.hair === 'long') return [[3, 3, 10, 10, h]];
  if (a.hair === 'bob') return [[3, 3, 10, 6, h]];
  return [];
}

function hairFront(a: AvatarConfig): R[] {
  const h = a.hairColor;
  const hi = shade(h, 0.12);
  switch (a.hair) {
    case 'short':
      return [[4, 1, 8, 2, h], [4, 3, 1, 2, h], [11, 3, 1, 2, h], [5, 1, 3, 1, hi]];
    case 'bob':
      return [[3, 1, 10, 2, h], [3, 3, 2, 5, h], [11, 3, 2, 5, h], [5, 3, 3, 1, h], [4, 1, 3, 1, hi]];
    case 'spiky':
      return [[4, 1, 8, 2, h], [4, 0, 1, 1, h], [6, -1, 1, 2, h], [8, 0, 1, 1, h], [10, -1, 1, 2, h], [11, 0, 1, 1, h], [4, 3, 1, 1, h], [11, 3, 1, 1, h], [6, 1, 2, 1, hi]];
    case 'long':
      return [[3, 1, 10, 2, h], [3, 3, 2, 4, h], [11, 3, 2, 4, h], [4, 1, 3, 1, hi]];
    case 'bun':
      return [[4, 1, 8, 2, h], [6, -1, 4, 2, h], [4, 3, 1, 2, h], [11, 3, 1, 2, h], [7, -1, 1, 1, hi]];
    case 'bald':
      return [[6, 2, 2, 1, shade(a.skin, 0.12)]];
  }
}

function accessory(a: AvatarConfig, color: string): R[] {
  switch (a.accessory) {
    case 'glasses':
      return [[5, 5, 3, 1, OUTLINE], [9, 5, 3, 1, OUTLINE], [8, 5, 1, 1, OUTLINE], [5, 6, 1, 1, OUTLINE], [7, 6, 1, 1, OUTLINE], [9, 6, 1, 1, OUTLINE], [11, 6, 1, 1, OUTLINE]];
    case 'headset':
      return [[4, 0, 8, 1, '#2a2f45'], [3, 1, 1, 3, '#2a2f45'], [12, 1, 1, 3, '#2a2f45'], [2, 4, 2, 3, '#2a2f45'], [12, 4, 2, 3, '#2a2f45'], [4, 7, 3, 1, '#2a2f45'], [7, 7, 1, 1, '#5ee0c0']];
    case 'cap':
      return [[4, 0, 8, 3, shade(color, -0.1)], [10, 2, 4, 1, shade(color, -0.25)], [6, 0, 2, 1, shade(color, 0.15)]];
    default:
      return [];
  }
}

export function spriteRects(a: AvatarConfig, color: string, pose: 'sit' | 'stand'): { body: R[]; eyes: R[]; arms: R[] } {
  const skin = a.skin;
  const skinShade = shade(skin, -0.08);
  const shirt = color;
  const shirtShade = shade(color, -0.18);
  const body: R[] = [
    ...hairBack(a),
    // kepala
    [4, 2, 8, 7, skin],
    [4, 8, 8, 1, skinShade],
    [3, 5, 1, 2, skin], // telinga
    [12, 5, 1, 2, skin],
    ...hairFront(a),
    [7, 8, 2, 1, shade(skin, -0.2)], // mulut
    // leher & badan
    [7, 9, 2, 1, skinShade],
    [3, 10, 10, 6, shirt],
    [3, 10, 10, 1, shade(color, 0.12)],
    [7, 10, 2, 2, shade(color, 0.25)], // kerah
    [3, 15, 10, 1, shirtShade],
  ];
  if (pose === 'stand') {
    body.push([4, 16, 8, 5, PANTS], [7, 17, 2, 4, shade(PANTS, -0.15)], [3, 21, 4, 1, OUTLINE], [9, 21, 4, 1, OUTLINE]);
  }
  body.push(...accessory(a, color));
  const eyes: R[] = [[6, 5, 1, 2, OUTLINE], [9, 5, 1, 2, OUTLINE]];
  const arms: R[] = [
    [2, 10, 1, 5, shirtShade],
    [13, 10, 1, 5, shirtShade],
    [2, 15, 1, 1, skin],
    [13, 15, 1, 1, skin],
  ];
  return { body, eyes, arms };
}

function Rects({ rects }: { rects: R[] }) {
  return (
    <>
      {rects.map(([x, y, w, h, f], i) => (
        <rect key={i} x={x * P} y={y * P} width={w * P} height={h * P} fill={f} />
      ))}
    </>
  );
}

/**
 * Karakter di dalam SVG kantor. (x, y) = titik tengah bawah sprite.
 * Animasi menyesuaikan status aktivitas.
 */
export function PixelCharacter({
  avatar,
  color,
  x,
  y,
  pose,
  status,
  delay = 0,
  dim,
  scale = 1,
}: {
  avatar: AvatarConfig;
  color: string;
  x: number;
  y: number;
  pose: 'sit' | 'stand';
  status: ActivityStatus;
  delay?: number;
  dim?: boolean;
  scale?: number;
}) {
  const rows = pose === 'stand' ? 22 : 16;
  const { body, eyes, arms } = spriteRects(avatar, color, pose);
  const ox = x - 8 * P * scale;
  const oy = y - rows * P * scale;
  const animate = status !== 'offline';
  return (
    <g transform={`translate(${ox} ${oy}) scale(${scale})`} shapeRendering="crispEdges" opacity={dim ? 0.92 : 1}>
      {/* bayangan */}
      {pose === 'stand' && <ellipse cx={8 * P} cy={rows * P} rx={6 * P} ry={1.4 * P} fill="#000" opacity={0.18} />}
      <g className={animate || pose === 'stand' ? 'vo-bob' : undefined} style={{ animationDelay: `${delay}s` }}>
        <Rects rects={body} />
        <g className="vo-blink" style={{ animationDelay: `${delay * 1.7}s` }}>
          <Rects rects={eyes} />
        </g>
        <g className={status === 'working' ? 'vo-type' : undefined}>
          <Rects rects={arms} />
        </g>
      </g>
    </g>
  );
}

/** Avatar mandiri (kepala + bahu) untuk daftar, chat, dan kartu. */
export function AvatarIcon({ avatar, color, size = 36, className }: { avatar: AvatarConfig; color: string; size?: number; className?: string }) {
  const { body, eyes } = spriteRects(avatar, color, 'sit');
  return (
    <svg
      width={size}
      height={size}
      viewBox={`${1 * P} ${-1 * P} ${14 * P} ${14 * P}`}
      className={className}
      shapeRendering="crispEdges"
      aria-hidden
      style={{ background: shade(color, 0.38), borderRadius: size * 0.28 }}
    >
      <Rects rects={body} />
      <Rects rects={eyes} />
    </svg>
  );
}
