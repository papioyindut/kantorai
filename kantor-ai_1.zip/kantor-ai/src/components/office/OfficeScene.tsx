// Kantor virtual 2D top-down bergaya pixel art. Semua aset digambar sendiri dengan SVG.
import { memo, useEffect, useState, type KeyboardEvent } from 'react';
import type { Desk, Employee } from '../../../shared/types';
import { LOUNGE_SPOTS, MAP_H, MAP_W, WALL_H, ZONES } from '../../../shared/officeLayout';
import { ACTIVITY_COLOR, ACTIVITY_LABEL, CONFIG_LABEL } from '../../lib/labels';
import { PixelCharacter } from './PixelAvatar';

export interface SceneAnchor {
  x: number;
  y: number;
}

interface Props {
  officeName: string;
  employees: Employee[]; // hanya yang aktif
  desks: Desk[];
  layoutMode: boolean;
  selectedId: string | null;
  selectedDeskId: string | null;
  onEmployeeClick: (emp: Employee, anchor: SceneAnchor) => void;
  onDeskClick: (desk: Desk, anchor: SceneAnchor) => void;
}

const FONT = 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';

function onKey(fn: () => void) {
  return (e: KeyboardEvent) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      fn();
    }
  };
}

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(h);
}

function truncate(s: string, n: number) {
  return s.length > n ? `${s.slice(0, n - 1)}…` : s;
}

/* ------------------------------ Dekorasi ------------------------------ */

function Defs() {
  return (
    <defs>
      <pattern id="vo-wood" width="96" height="24" patternUnits="userSpaceOnUse">
        <rect width="96" height="24" fill="#c99d6b" />
        <rect y="8" width="96" height="8" fill="#c49866" />
        <rect y="7" width="96" height="1" fill="#b48a5c" />
        <rect y="15" width="96" height="1" fill="#b48a5c" />
        <rect y="23" width="96" height="1" fill="#b48a5c" />
        <rect x="0" y="0" width="1" height="7" fill="#b48a5c" />
        <rect x="48" y="0" width="1" height="7" fill="#b48a5c" />
        <rect x="24" y="8" width="1" height="7" fill="#b48a5c" />
        <rect x="72" y="8" width="1" height="7" fill="#b48a5c" />
        <rect x="12" y="16" width="1" height="7" fill="#b48a5c" />
        <rect x="60" y="16" width="1" height="7" fill="#b48a5c" />
        <rect x="8" y="3" width="14" height="1" fill="#d2a978" />
        <rect x="58" y="11" width="10" height="1" fill="#d2a978" />
        <rect x="30" y="19" width="12" height="1" fill="#d2a978" />
      </pattern>
      <pattern id="vo-carpet" width="16" height="16" patternUnits="userSpaceOnUse">
        <rect width="16" height="16" fill="#5d6aa0" />
        <rect width="8" height="8" fill="#6573aa" />
        <rect x="8" y="8" width="8" height="8" fill="#6573aa" />
      </pattern>
      <pattern id="vo-tile" width="16" height="16" patternUnits="userSpaceOnUse">
        <rect width="16" height="16" fill="#e3d4b6" />
        <rect width="16" height="1" fill="#d3c19e" />
        <rect width="1" height="16" fill="#d3c19e" />
      </pattern>
      <linearGradient id="vo-sky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#8fcaf9" />
        <stop offset="1" stopColor="#d4eeff" />
      </linearGradient>
      <clipPath id="vo-win1"><rect x="26" y="9" width="92" height="27" /></clipPath>
      <clipPath id="vo-win2"><rect x="154" y="9" width="92" height="27" /></clipPath>
    </defs>
  );
}

function Window({ x, clip, offset }: { x: number; clip: string; offset: number }) {
  return (
    <g>
      <rect x={x - 2} y={7} width={96} height={31} fill="#2c3150" />
      <rect x={x} y={9} width={92} height={27} fill="url(#vo-sky)" />
      <g clipPath={`url(#${clip})`}>
        <g className="vo-cloud" style={{ animationDelay: `${-offset}s` }}>
          <rect x={x + 6} y={14} width={22} height={6} fill="#fff" opacity={0.9} />
          <rect x={x + 10} y={11} width={12} height={4} fill="#fff" opacity={0.9} />
          <rect x={x + 44} y={22} width={18} height={5} fill="#fff" opacity={0.75} />
        </g>
        {/* siluet kota */}
        <rect x={x} y={28} width={92} height={8} fill="#9db7cf" />
        <rect x={x + 8} y={22} width={10} height={14} fill="#8aa6c1" />
        <rect x={x + 40} y={19} width={12} height={17} fill="#8aa6c1" />
        <rect x={x + 70} y={24} width={14} height={12} fill="#8aa6c1" />
      </g>
      <rect x={x + 45} y={9} width={2} height={27} fill="#2c3150" />
      <rect x={x} y={21} width={92} height={2} fill="#2c3150" />
      <rect x={x - 4} y={38} width={100} height={3} fill="#5a6290" />
    </g>
  );
}

function Plant({ x, y, big }: { x: number; y: number; big?: boolean }) {
  const s = big ? 1.25 : 1;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <ellipse cx={0} cy={2} rx={10} ry={3} fill="#000" opacity={0.15} />
      <g className="vo-sway" style={{ animationDelay: `${(x % 7) * 0.4}s` }}>
        <rect x={-2} y={-26} width={4} height={14} fill="#2f7d4a" />
        <rect x={-10} y={-24} width={8} height={6} fill="#3fa55f" />
        <rect x={2} y={-28} width={9} height={6} fill="#3fa55f" />
        <rect x={-7} y={-32} width={7} height={6} fill="#4cbf6f" />
        <rect x={1} y={-20} width={8} height={5} fill="#4cbf6f" />
        <rect x={-9} y={-17} width={7} height={5} fill="#2f8f50" />
      </g>
      <rect x={-8} y={-12} width={16} height={13} fill="#c4673f" />
      <rect x={-9} y={-13} width={18} height={3} fill="#d97b52" />
    </g>
  );
}

function WallClock({ x, y }: { x: number; y: number }) {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = window.setInterval(() => setNow(new Date()), 30_000);
    return () => window.clearInterval(t);
  }, []);
  const m = now.getMinutes();
  const h = (now.getHours() % 12) + m / 60;
  const hand = (deg: number, len: number) => ({
    x2: x + Math.sin((deg * Math.PI) / 180) * len,
    y2: y - Math.cos((deg * Math.PI) / 180) * len,
  });
  return (
    <g>
      <circle cx={x} cy={y} r={10} fill="#2c3150" />
      <circle cx={x} cy={y} r={8} fill="#fdf8ec" />
      <line x1={x} y1={y} {...hand(h * 30, 4.5)} stroke="#2c3150" strokeWidth={1.6} />
      <line x1={x} y1={y} {...hand(m * 6, 6.5)} stroke="#2c3150" strokeWidth={1} />
      <title>{now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}</title>
    </g>
  );
}

function StaticDecor({ officeName }: { officeName: string }) {
  const W = ZONES.work, M = ZONES.meeting, L = ZONES.lounge;
  return (
    <g shapeRendering="crispEdges">
      {/* lantai */}
      <rect x={W.x} y={W.y} width={W.w} height={W.h} fill="url(#vo-wood)" />
      <rect x={M.x} y={M.y} width={M.w} height={M.h} fill="url(#vo-carpet)" />
      <rect x={L.x} y={L.y} width={L.w} height={L.h} fill="url(#vo-tile)" />

      {/* dinding atas */}
      <rect x={0} y={0} width={MAP_W} height={WALL_H} fill="#474e78" />
      <rect x={0} y={0} width={MAP_W} height={4} fill="#363c62" />
      <rect x={0} y={WALL_H - 5} width={MAP_W} height={5} fill="#2c3150" />
      <Window x={26} clip="vo-win1" offset={0} />
      <Window x={154} clip="vo-win2" offset={17} />

      {/* papan nama kantor */}
      <rect x={288} y={10} width={164} height={26} rx={2} fill="#1b2036" />
      <rect x={290} y={12} width={160} height={22} fill="#232945" />
      <rect x={296} y={19} width={6} height={8} fill="#f4b740" />
      <rect x={298} y={21} width={2} height={2} fill="#1b2036" />
      <text x={372} y={27} textAnchor="middle" fontFamily={FONT} fontSize={10} fontWeight={700} fill="#f4b740" letterSpacing={0.5}>
        {truncate(officeName.toUpperCase(), 22)}
      </text>
      <WallClock x={474} y={23} />

      {/* ruang meeting: whiteboard + TV */}
      <rect x={526} y={9} width={92} height={30} fill="#d9dde8" />
      <rect x={528} y={11} width={88} height={26} fill="#ffffff" />
      <polyline points="534,30 546,22 556,27 568,16 580,24" fill="none" stroke="#4f8cff" strokeWidth={1.5} />
      <rect x={588} y={16} width={22} height={2} fill="#e0703a" />
      <rect x={588} y={21} width={16} height={2} fill="#94a3b8" />
      <rect x={588} y={26} width={19} height={2} fill="#94a3b8" />
      <rect x={640} y={9} width={78} height={32} fill="#1b2036" />
      <rect x={643} y={12} width={72} height={26} fill="#27406b" />
      <text x={679} y={28} textAnchor="middle" fontFamily={FONT} fontSize={7} fill="#9fd3ff">RUANG MEETING</text>
      <WallClock x={744} y={23} />

      {/* sekat kaca */}
      <rect x={496} y={WALL_H} width={8} height={MAP_H - WALL_H} fill="#3a4066" />
      <rect x={496} y={128} width={8} height={56} fill="url(#vo-wood)" />
      <rect x={496} y={300} width={8} height={56} fill="url(#vo-wood)" />
      <rect x={498} y={WALL_H} width={4} height={80} fill="#a9d6e5" opacity={0.55} />
      <rect x={498} y={184} width={4} height={116} fill="#a9d6e5" opacity={0.55} />
      <rect x={504} y={224} width={MAP_W - 504} height={8} fill="#3a4066" />
      <rect x={604} y={224} width={56} height={8} fill="url(#vo-tile)" />
      <rect x={504} y={226} width={100} height={4} fill="#a9d6e5" opacity={0.55} />
      <rect x={660} y={226} width={108} height={4} fill="#a9d6e5" opacity={0.55} />

      {/* meja meeting */}
      {[586, 636, 686].map((cx) => (
        <g key={`t${cx}`}>
          <rect x={cx - 10} y={86} width={20} height={14} rx={2} fill="#39406a" />
          <rect x={cx - 10} y={168} width={20} height={14} rx={2} fill="#39406a" />
        </g>
      ))}
      <rect x={556} y={104} width={160} height={6} fill="#000" opacity={0.12} />
      <rect x={560} y={98} width={152} height={62} rx={6} fill="#7a5232" />
      <rect x={564} y={100} width={144} height={54} rx={4} fill="#946642" />
      <rect x={592} y={118} width={20} height={13} fill="#d9dde8" />
      <rect x={594} y={120} width={16} height={9} fill="#3b4a7a" />
      <rect x={640} y={114} width={14} height={18} fill="#fdf8ec" />
      <rect x={642} y={117} width={10} height={1} fill="#94a3b8" />
      <rect x={642} y={121} width={8} height={1} fill="#94a3b8" />
      <rect x={672} y={122} width={7} height={8} fill="#ef4f6b" />
      <text x={636} y={210} textAnchor="middle" fontFamily={FONT} fontSize={7} fill="#c8d0f0" opacity={0.75}>
        Segera hadir: meeting antar-AI
      </text>
      <Plant x={526} y={214} />

      {/* area santai */}
      <rect x={526} y={292} width={224} height={142} rx={6} fill="#b86f52" opacity={0.85} />
      <rect x={532} y={298} width={212} height={130} rx={4} fill="none" stroke="#e7b48e" strokeWidth={2} strokeDasharray="6 4" />
      {/* sofa */}
      <rect x={522} y={240} width={150} height={34} rx={4} fill="#357573" />
      <rect x={526} y={244} width={142} height={14} rx={3} fill="#4b9a96" />
      {[530, 576, 622].map((x) => (
        <rect key={x} x={x} y={258} width={42} height={12} rx={2} fill="#5bb0ab" />
      ))}
      {/* meja kopi */}
      <rect x={604} y={356} width={64} height={22} rx={3} fill="#6e4a2b" />
      <rect x={606} y={354} width={60} height={18} rx={3} fill="#8f6340" />
      <rect x={616} y={358} width={7} height={7} fill="#fdf8ec" />
      <rect x={646} y={359} width={12} height={8} fill="#4f8cff" />
      {/* pantry */}
      <rect x={690} y={238} width={70} height={40} fill="#5a6290" />
      <rect x={690} y={238} width={70} height={6} fill="#6b74a4" />
      <rect x={700} y={244} width={22} height={26} fill="#2a2f45" />
      <rect x={704} y={248} width={14} height={6} fill="#5ee0c0" />
      <rect x={707} y={262} width={8} height={6} fill="#fdf8ec" />
      <g>
        <rect className="vo-steam" x={709} y={254} width={2} height={5} fill="#ffffff" />
        <rect className="vo-steam" style={{ animationDelay: '1.1s' }} x={712} y={255} width={2} height={4} fill="#ffffff" />
      </g>
      <rect x={730} y={248} width={22} height={22} fill="#e2e8f0" />
      <rect x={733} y={251} width={16} height={8} fill="#cbd5e1" />
      <Plant x={752} y={440} big />

      {/* dekor area kerja */}
      <g>
        <rect x={10} y={54} width={30} height={22} fill="#d9dde8" />
        <rect x={12} y={56} width={26} height={8} fill="#94a3b8" />
        <rect x={16} y={66} width={18} height={3} fill="#fdf8ec" />
        <rect x={10} y={76} width={30} height={10} fill="#64748b" />
        <title>Printer</title>
      </g>
      <g>
        <rect x={462} y={52} width={18} height={12} fill="#9fd3ff" opacity={0.85} />
        <rect x={460} y={64} width={22} height={24} fill="#e2e8f0" />
        <rect x={466} y={70} width={4} height={3} fill="#4f8cff" />
        <rect x={472} y={70} width={4} height={3} fill="#ef4f6b" />
        <title>Dispenser air</title>
      </g>
      <Plant x={16} y={440} big />
      <Plant x={480} y={440} />

      {/* label zona */}
      <ZoneLabel x={12} y={WALL_H + 14} text="AREA KERJA" />
      <ZoneLabel x={512} y={WALL_H + 14} text="RUANG MEETING" />
      <ZoneLabel x={512} y={L.y + 14} text="AREA SANTAI" />
    </g>
  );
}

function ZoneLabel({ x, y, text }: { x: number; y: number; text: string }) {
  const w = text.length * 5.6 + 10;
  return (
    <g opacity={0.9}>
      <rect x={x + (x < 100 ? 34 : 0)} y={y - 9} width={w} height={12} rx={2} fill="#1b2036" opacity={0.7} />
      <text x={x + (x < 100 ? 34 : 0) + 5} y={y} fontFamily={FONT} fontSize={8} fontWeight={700} fill="#fdf8ec">
        {text}
      </text>
    </g>
  );
}

/* ------------------------------ Karyawan ------------------------------ */

function NameTag({ emp, x, y }: { emp: Employee; x: number; y: number }) {
  const name = truncate(emp.name, 14);
  const role = truncate(emp.role, 18);
  const w = Math.max(name.length * 5.2 + 22, role.length * 4.3 + 14, 46);
  return (
    <g pointerEvents="none">
      <rect x={x - w / 2} y={y + 1} width={w} height={22} rx={4} fill="#000" opacity={0.12} />
      <rect x={x - w / 2} y={y} width={w} height={22} rx={4} fill="#fffdf7" stroke={emp.color} strokeWidth={1.2} />
      <circle cx={x - w / 2 + 8} cy={y + 7.5} r={2.6} fill={ACTIVITY_COLOR[emp.activityStatus]} className={emp.activityStatus === 'working' ? 'vo-pulse' : undefined} />
      <text x={x - w / 2 + 14} y={y + 10} fontFamily={FONT} fontSize={8} fontWeight={700} fill="#1b2036">
        {name}
      </text>
      <text x={x - w / 2 + 7} y={y + 18.5} fontFamily={FONT} fontSize={6.4} fill="#64748b">
        {role}
      </text>
    </g>
  );
}

function Bubble({ x, y, kind }: { x: number; y: number; kind: 'waiting' | 'error' }) {
  return (
    <g className="vo-float" pointerEvents="none">
      <rect x={x - 10} y={y - 12} width={20} height={12} rx={3} fill={kind === 'error' ? '#ef4444' : '#fffdf7'} stroke="#1b2036" strokeWidth={1} />
      <rect x={x - 2} y={y} width={4} height={3} fill={kind === 'error' ? '#ef4444' : '#fffdf7'} />
      <text x={x} y={y - 3} textAnchor="middle" fontFamily={FONT} fontSize={9} fontWeight={700} fill={kind === 'error' ? '#fff' : '#1b2036'}>
        {kind === 'error' ? '!' : '…'}
      </text>
    </g>
  );
}

function tooltip(emp: Employee) {
  return `${emp.name} · ${emp.role}\n${ACTIVITY_LABEL[emp.activityStatus]} · ${CONFIG_LABEL[emp.configStatus]}`;
}

const DeskSprite = memo(function DeskSprite({
  desk,
  emp,
  layoutMode,
  selected,
  deskSelected,
  onEmployeeClick,
  onDeskClick,
}: {
  desk: Desk;
  emp: Employee | undefined;
  layoutMode: boolean;
  selected: boolean;
  deskSelected: boolean;
  onEmployeeClick: Props['onEmployeeClick'];
  onDeskClick: Props['onDeskClick'];
}) {
  const { x: cx, y: ty } = desk;
  const status = emp?.activityStatus ?? 'offline';
  const led = emp ? ACTIVITY_COLOR[status] : '#4b5563';
  const click = () => (layoutMode || !emp ? onDeskClick(desk, { x: cx, y: ty - 30 }) : onEmployeeClick(emp, { x: cx, y: ty - 30 }));
  const label = emp
    ? layoutMode
      ? `${desk.label}: ${emp.name}. Klik untuk memindahkan.`
      : `${emp.name}, ${emp.role}. Klik untuk membuka profil dan chat.`
    : `${desk.label} kosong. Klik untuk menempatkan karyawan.`;
  const charX = cx - 9;

  return (
    <g
      className="office-hit"
      role="button"
      tabIndex={0}
      aria-label={label}
      data-desk-id={desk.id}
      data-employee-id={emp?.id}
      onClick={click}
      onKeyDown={onKey(click)}
    >
      <title>{emp ? tooltip(emp) : `${desk.label} — kosong`}</title>
      {/* area klik + sorotan */}
      <rect x={cx - 44} y={ty - 46} width={88} height={106} fill="transparent" />
      <rect
        className={selected || deskSelected ? undefined : 'office-focus'}
        x={cx - 42}
        y={ty - 44}
        width={84}
        height={102}
        rx={6}
        fill={emp ? emp.color : '#f4b740'}
        fillOpacity={0.1}
        stroke={selected || deskSelected ? '#f4b740' : emp ? emp.color : '#f4b740'}
        strokeWidth={selected || deskSelected ? 2 : 1.4}
        strokeDasharray={selected || deskSelected ? undefined : '4 3'}
      />
      {layoutMode && (
        <rect x={cx - 40} y={ty - 42} width={80} height={98} rx={6} fill="none" stroke={emp ? '#ffffff' : '#f4b740'} strokeWidth={1.4} strokeDasharray="5 3" opacity={0.9} />
      )}
      <g shapeRendering="crispEdges">
        <rect x={cx - 38} y={ty + 30} width={76} height={4} fill="#000" opacity={0.14} />
        {/* kursi */}
        <rect x={charX - 15} y={ty - (emp ? 26 : 18)} width={30} height={emp ? 26 : 20} rx={4} fill="#39406a" />
        <rect x={charX - 12} y={ty - (emp ? 23 : 15)} width={24} height={4} rx={1} fill="#4b5388" />
      </g>
      {emp && <PixelCharacter avatar={emp.avatar} color={emp.color} x={charX} y={ty + 8} pose="sit" status={status} delay={(hash(emp.id) % 20) / 10} dim={status === 'offline'} scale={1.4} />}
      <g shapeRendering="crispEdges">
        {/* meja */}
        <rect x={cx - 36} y={ty} width={72} height={16} fill="#c08a55" />
        <rect x={cx - 36} y={ty} width={72} height={2} fill="#d6a06a" />
        <rect x={cx - 36} y={ty + 16} width={72} height={12} fill="#93633a" />
        <rect x={cx - 34} y={ty + 28} width={4} height={5} fill="#6e4a2b" />
        <rect x={cx + 30} y={ty + 28} width={4} height={5} fill="#6e4a2b" />
        {/* monitor (tampak belakang) */}
        <rect x={cx + 13} y={ty - 14} width={21} height={17} fill="#2a2f45" />
        <rect x={cx + 15} y={ty - 12} width={17} height={1} fill="#3b4263" />
        <rect x={cx + 21} y={ty + 3} width={4} height={4} fill="#2a2f45" />
        <rect x={cx + 17} y={ty + 6} width={12} height={2} fill="#2a2f45" />
        <rect x={cx + 29} y={ty - 1} width={3} height={2} fill={led} className={status === 'working' ? 'vo-pulse' : undefined} />
        {status === 'working' && <rect x={cx + 11} y={ty - 16} width={26} height={21} fill="#60a5fa" opacity={0.18} />}
        {/* keyboard, mug, kertas */}
        <rect x={charX - 10} y={ty + 6} width={18} height={4} fill="#e5e7eb" />
        <rect x={charX - 10} y={ty + 6} width={18} height={1} fill="#f8fafc" />
        <rect x={cx - 33} y={ty + 3} width={6} height={7} fill={emp?.color ?? '#94a3b8'} />
        <rect x={cx - 27} y={ty + 5} width={2} height={3} fill={emp?.color ?? '#94a3b8'} />
        {emp && <rect x={cx + 2} y={ty + 9} width={9} height={5} fill="#fdf8ec" />}
      </g>
      {emp && status === 'waiting' && <Bubble x={charX} y={ty - 40} kind="waiting" />}
      {emp && status === 'error' && <Bubble x={charX} y={ty - 40} kind="error" />}
      {emp ? (
        <NameTag emp={emp} x={cx} y={ty + 36} />
      ) : (
        <g pointerEvents="none" opacity={layoutMode ? 1 : 0.55}>
          <rect x={cx - 30} y={ty + 37} width={60} height={14} rx={3} fill="#fffdf7" opacity={0.7} stroke="#d6c7a8" strokeDasharray="3 2" />
          <text x={cx} y={ty + 47} textAnchor="middle" fontFamily={FONT} fontSize={7} fill="#7c6a4d">
            {layoutMode ? '+ Tempatkan' : desk.label}
          </text>
        </g>
      )}
    </g>
  );
});

function LoungeEmployee({
  emp,
  spot,
  selected,
  layoutMode,
  onClick,
}: {
  emp: Employee;
  spot: { x: number; y: number };
  selected: boolean;
  layoutMode: boolean;
  onClick: Props['onEmployeeClick'];
}) {
  const click = () => onClick(emp, { x: spot.x, y: spot.y - 56 });
  return (
    <g
      className="office-hit"
      role="button"
      tabIndex={0}
      aria-label={`${emp.name}, ${emp.role}, belum punya meja. ${layoutMode ? 'Klik untuk memilih meja.' : 'Klik untuk membuka profil.'}`}
      data-employee-id={emp.id}
      onClick={click}
      onKeyDown={onKey(click)}
    >
      <title>{`${tooltip(emp)}\nBelum punya meja`}</title>
      <rect x={spot.x - 28} y={spot.y - 62} width={56} height={90} fill="transparent" />
      <rect
        className={selected ? undefined : 'office-focus'}
        x={spot.x - 26}
        y={spot.y - 60}
        width={52}
        height={88}
        rx={6}
        fill={emp.color}
        fillOpacity={0.12}
        stroke={selected ? '#f4b740' : emp.color}
        strokeWidth={selected ? 2 : 1.4}
        strokeDasharray={selected ? undefined : '4 3'}
      />
      <PixelCharacter avatar={emp.avatar} color={emp.color} x={spot.x} y={spot.y} pose="stand" status={emp.activityStatus} delay={(hash(emp.id) % 20) / 10} scale={1.25} />
      <NameTag emp={emp} x={spot.x} y={spot.y + 4} />
    </g>
  );
}

/* -------------------------------- Scene ------------------------------- */

export function OfficeScene(props: Props) {
  const { employees, desks, layoutMode, selectedId, selectedDeskId, onEmployeeClick, onDeskClick, officeName } = props;
  const byId = new Map(employees.map((e) => [e.id, e]));
  const seated = new Set(desks.map((d) => d.employeeId).filter(Boolean));
  const lounge = employees.filter((e) => !seated.has(e.id));

  return (
    <svg
      viewBox={`0 0 ${MAP_W} ${MAP_H}`}
      className="block h-full w-full select-none"
      role="img"
      aria-label={`Denah ${officeName}: ${employees.length} karyawan AI`}
    >
      <Defs />
      <StaticDecor officeName={officeName} />
      {desks.map((d) => (
        <DeskSprite
          key={d.id}
          desk={d}
          emp={d.employeeId ? byId.get(d.employeeId) : undefined}
          layoutMode={layoutMode}
          selected={!!d.employeeId && d.employeeId === selectedId}
          deskSelected={d.id === selectedDeskId}
          onEmployeeClick={onEmployeeClick}
          onDeskClick={onDeskClick}
        />
      ))}
      {lounge.slice(0, LOUNGE_SPOTS.length).map((e, i) => (
        <LoungeEmployee key={e.id} emp={e} spot={LOUNGE_SPOTS[i]} selected={e.id === selectedId} layoutMode={layoutMode} onClick={onEmployeeClick} />
      ))}
      {lounge.length > LOUNGE_SPOTS.length && (
        <text x={636} y={300} textAnchor="middle" fontFamily={FONT} fontSize={8} fill="#1b2036">
          +{lounge.length - LOUNGE_SPOTS.length} lainnya (lihat daftar Karyawan)
        </text>
      )}
    </svg>
  );
}
