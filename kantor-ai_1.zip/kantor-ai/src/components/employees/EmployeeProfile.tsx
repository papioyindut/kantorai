import { useEffect, useState, type ReactNode } from 'react';
import type { AIConfig, Employee, Task } from '../../../shared/types';
import { api } from '../../api/client';
import { ACTIVITY_LABEL, formatDateTime, TASK_STATUS_ACCENT, TASK_STATUS_LABEL } from '../../lib/labels';
import { closeProfile, openProfile, type Route } from '../../lib/router';
import { useData } from '../../state/DataContext';
import { ChatPanel } from '../chat/ChatPanel';
import { AvatarIcon } from '../office/PixelAvatar';
import { TaskCard } from '../tasks/TaskCard';
import { TaskModal } from '../tasks/TaskModal';
import { IconArchive, IconChat, IconEdit, IconFlow, IconLock, IconPlus, IconRestore, IconX } from '../ui/icons';
import { ActivityBadge, Button, Callout, ConfigBadge, ConfirmModal, EmptyState, Field, inputCls, Skeleton, SoonBadge, Tabs } from '../ui/ui';
import { EmployeeFormModal } from './EmployeeFormModal';

export type ProfileTab = 'overview' | 'chat' | 'tasks' | 'workflow' | 'settings';
const TABS: { id: ProfileTab; label: string }[] = [
  { id: 'overview', label: 'Overview' },
  { id: 'chat', label: 'Chat' },
  { id: 'tasks', label: 'Tasks' },
  { id: 'workflow', label: 'Workflow' },
  { id: 'settings', label: 'Settings' },
];

export function EmployeeProfileDrawer({ route }: { route: Route }) {
  const { employeeById, loading } = useData();
  const id = route.query.get('profile');
  const tabParam = route.query.get('tab') as ProfileTab | null;
  const tab: ProfileTab = TABS.some((t) => t.id === tabParam) ? tabParam! : 'overview';
  const emp = employeeById(id);

  useEffect(() => {
    if (!id) return;
    const on = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && !document.querySelector('[role="dialog"][aria-modal="true"]')) closeProfile(route);
    };
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, [id, route]);

  if (!id) return null;
  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-ink-950/25" onMouseDown={() => closeProfile(route)}>
      <aside
        className="vo-slide-in flex h-full w-full max-w-[560px] flex-col bg-paper shadow-2xl"
        onMouseDown={(e) => e.stopPropagation()}
        aria-label="Profil karyawan"
        data-testid="profile-drawer"
      >
        {!emp ? (
          <div className="p-6">
            {loading ? (
              <Skeleton className="h-24" />
            ) : (
              <EmptyState title="Karyawan tidak ditemukan" action={<Button onClick={() => closeProfile(route)}>Tutup</Button>}>
                Mungkin data sudah berubah. Pilih karyawan lain dari kantor atau daftar karyawan.
              </EmptyState>
            )}
          </div>
        ) : (
          <>
            <header className="flex items-start gap-4 px-5 pt-5 pb-4">
              <AvatarIcon avatar={emp.avatar} color={emp.color} size={64} />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="truncate text-xl font-bold">{emp.name}</h2>
                  {emp.archived && <span className="rounded bg-slate-200 px-1.5 py-0.5 text-[11px] font-semibold text-slate-600">Diarsipkan</span>}
                </div>
                <div className="text-sm text-slate-500">{emp.role}</div>
                <div className="mt-2 flex flex-wrap gap-1.5">
                  <ConfigBadge status={emp.configStatus} />
                  <ActivityBadge status={emp.activityStatus} />
                </div>
              </div>
              <button type="button" onClick={() => closeProfile(route)} className="rounded-md p-1.5 text-slate-500 hover:bg-ink-900/5" aria-label="Tutup profil">
                <IconX />
              </button>
            </header>
            <Tabs tabs={TABS} value={tab} onChange={(t) => openProfile(route, emp.id, t)} />
            <div className="min-h-0 flex-1 overflow-hidden">
              {tab === 'overview' && <OverviewTab emp={emp} route={route} />}
              {tab === 'chat' && <ChatPanel employee={emp} compact />}
              {tab === 'tasks' && <TasksTab emp={emp} />}
              {tab === 'workflow' && <WorkflowTab emp={emp} />}
              {tab === 'settings' && <SettingsTab emp={emp} />}
            </div>
          </>
        )}
      </aside>
    </div>
  );
}

function Section({ title, children, right }: { title: string; children: ReactNode; right?: ReactNode }) {
  return (
    <section className="rounded-xl bg-white p-4 ring-1 ring-line">
      <div className="mb-2 flex items-center justify-between">
        <h3 className="text-[13px] font-semibold uppercase tracking-wide text-slate-500">{title}</h3>
        {right}
      </div>
      {children}
    </section>
  );
}

function OverviewTab({ emp, route }: { emp: Employee; route: Route }) {
  const { desks, employeeById, reloadEmployees, toast, toastError, taskRevision } = useData();
  const [tasks, setTasks] = useState<Task[] | null>(null);
  const [savingDesk, setSavingDesk] = useState(false);
  useEffect(() => {
    api.tasks(emp.id).then(setTasks).catch(() => setTasks([]));
  }, [emp.id, taskRevision]);

  async function changeDesk(deskId: string) {
    setSavingDesk(true);
    try {
      await api.assignDesk(emp.id, deskId || null);
      await reloadEmployees();
      toast(deskId ? 'Posisi meja disimpan.' : 'Dipindah ke area santai.');
    } catch (e) {
      toastError(e);
    } finally {
      setSavingDesk(false);
    }
  }

  const open = (tasks ?? []).filter((t) => t.status !== 'done').length;
  return (
    <div className="thin-scroll h-full space-y-3 overflow-y-auto p-5">
      <div className="flex gap-2">
        <Button variant="primary" onClick={() => openProfile(route, emp.id, 'chat')}>
          <IconChat size={16} /> Chat
        </Button>
        <Button onClick={() => openProfile(route, emp.id, 'settings')}>
          <IconEdit size={16} /> Edit profil
        </Button>
      </div>
      <Section title="Tentang">
        <p className="whitespace-pre-wrap text-sm text-ink-800">{emp.description || <span className="text-slate-400">Belum ada deskripsi.</span>}</p>
      </Section>
      <Section title="Status">
        <dl className="grid grid-cols-[140px_1fr] gap-y-2 text-sm">
          <dt className="text-slate-500">Konfigurasi</dt>
          <dd><ConfigBadge status={emp.configStatus} /></dd>
          <dt className="text-slate-500">Aktivitas</dt>
          <dd>
            <ActivityBadge status={emp.activityStatus} />
            {emp.configStatus !== 'ready' && (
              <span className="ml-2 text-xs text-slate-500">{ACTIVITY_LABEL.offline} karena runtime AI belum terhubung.</span>
            )}
          </dd>
          <dt className="text-slate-500">Bergabung</dt>
          <dd>{formatDateTime(emp.createdAt)}</dd>
        </dl>
      </Section>
      <Section title="Meja">
        <select
          aria-label="Pilih meja"
          className={inputCls()}
          value={emp.deskId ?? ''}
          disabled={emp.archived || savingDesk}
          onChange={(e) => changeDesk(e.target.value)}
        >
          <option value="">Tanpa meja (area santai)</option>
          {desks.map((d) => {
            const occ = d.employeeId && d.employeeId !== emp.id ? employeeById(d.employeeId) : undefined;
            return (
              <option key={d.id} value={d.id}>
                {d.label}
                {occ ? ` — ditempati ${occ.name}` : d.employeeId === emp.id ? ' — saat ini' : ' — kosong'}
              </option>
            );
          })}
        </select>
        {emp.archived && <p className="mt-1 text-xs text-slate-500">Karyawan yang diarsipkan tidak menempati meja.</p>}
      </Section>
      <Section title="Tugas">
        {tasks === null ? (
          <Skeleton className="h-6 w-40" />
        ) : (
          <div className="flex items-center justify-between text-sm">
            <span>
              <b>{open}</b> aktif · <b>{tasks.length - open}</b> selesai
            </span>
            <button type="button" className="text-sm font-medium text-ink-700 underline underline-offset-2" onClick={() => openProfile(route, emp.id, 'tasks')}>
              Lihat tugas
            </button>
          </div>
        )}
      </Section>
    </div>
  );
}

function TasksTab({ emp }: { emp: Employee }) {
  const { taskRevision } = useData();
  const [tasks, setTasks] = useState<Task[] | null>(null);
  const [editing, setEditing] = useState<Task | null>(null);
  const [creating, setCreating] = useState(false);
  useEffect(() => {
    api.tasks(emp.id).then(setTasks).catch(() => setTasks([]));
  }, [emp.id, taskRevision]);

  return (
    <div className="thin-scroll h-full space-y-3 overflow-y-auto p-5">
      <div className="flex items-center justify-between">
        <p className="text-sm text-slate-500">Tugas yang ditugaskan ke {emp.name}.</p>
        <Button variant="primary" size="sm" onClick={() => setCreating(true)} disabled={emp.archived}>
          <IconPlus size={15} /> Tugas baru
        </Button>
      </div>
      <Callout>Tahap ini: tugas dikelola manual. Menugaskan ke AI belum menjalankan workflow.</Callout>
      {tasks === null ? (
        <Skeleton className="h-20" />
      ) : tasks.length === 0 ? (
        <EmptyState title="Belum ada tugas">Buat tugas baru dan tugaskan ke {emp.name}.</EmptyState>
      ) : (
        (['in_progress', 'review', 'todo', 'backlog', 'done'] as const).map((s) => {
          const list = tasks.filter((t) => t.status === s);
          if (!list.length) return null;
          return (
            <div key={s} className="space-y-2">
              <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-500">
                <span className="size-2 rounded-full" style={{ background: TASK_STATUS_ACCENT[s] }} />
                {TASK_STATUS_LABEL[s]} ({list.length})
              </div>
              {list.map((t) => (
                <TaskCard key={t.id} task={t} onOpen={() => setEditing(t)} />
              ))}
            </div>
          );
        })
      )}
      <TaskModal open={creating} onClose={() => setCreating(false)} defaults={{ assigneeId: emp.id, status: 'todo' }} />
      <TaskModal open={!!editing} task={editing} onClose={() => setEditing(null)} />
    </div>
  );
}

function WorkflowTab({ emp }: { emp: Employee }) {
  return (
    <div className="thin-scroll h-full space-y-4 overflow-y-auto p-5" data-testid="workflow-tab">
      <EmptyState
        icon={<IconFlow size={36} />}
        title="Workflow belum disetup"
        action={
          <Button disabled title="Tersedia pada tahap berikutnya">
            <IconLock size={15} /> Setup workflow <SoonBadge />
          </Button>
        }
      >
        {emp.name} belum memiliki workflow, instruksi kerja, atau tools. Konfigurasi ini akan dilakukan pada tahap berikutnya — kantor dan messenger tidak perlu diubah.
      </EmptyState>
    </div>
  );
}

function SettingsTab({ emp }: { emp: Employee }) {
  const { reloadEmployees, toast, toastError } = useData();
  const [editOpen, setEditOpen] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [busy, setBusy] = useState(false);
  const [config, setConfig] = useState<AIConfig | null>(null);
  useEffect(() => {
    api.config(emp.id).then(setConfig).catch(() => setConfig(null));
  }, [emp.id]);

  async function toggleArchive() {
    setBusy(true);
    try {
      if (emp.archived) await api.restoreEmployee(emp.id);
      else await api.archiveEmployee(emp.id);
      await reloadEmployees();
      toast(emp.archived ? `${emp.name} aktif kembali.` : `${emp.name} diarsipkan.`);
      setConfirm(false);
    } catch (e) {
      toastError(e);
    } finally {
      setBusy(false);
    }
  }

  const show = (v: unknown) => (v == null || (Array.isArray(v) && !v.length) ? '' : typeof v === 'string' ? v : JSON.stringify(v));

  return (
    <div className="thin-scroll h-full space-y-3 overflow-y-auto p-5">
      <Section title="Profil" right={<Button size="sm" onClick={() => setEditOpen(true)}><IconEdit size={15} /> Edit</Button>}>
        <p className="text-sm text-slate-600">Nama, jabatan, deskripsi, avatar, warna identitas, dan meja.</p>
      </Section>

      <Section title="Konfigurasi AI" right={<SoonBadge />}>
        <p className="mb-3 text-sm text-slate-600">
          Struktur konfigurasi sudah tersedia dan tersimpan per karyawan, tetapi masih kosong. Pengisian dilakukan pada tahap berikutnya.
        </p>
        {!config ? (
          <Skeleton className="h-32" />
        ) : (
          <fieldset disabled className="space-y-3" data-testid="ai-config">
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Provider"><input className={inputCls()} value={show(config.provider)} placeholder="Belum dipilih" readOnly /></Field>
              <Field label="Model"><input className={inputCls()} value={show(config.model)} placeholder="Belum dipilih" readOnly /></Field>
            </div>
            <Field label="System prompt"><textarea rows={2} className={inputCls()} value={show(config.systemPrompt)} placeholder="Kosong" readOnly /></Field>
            <Field label="Tools"><input className={inputCls()} value={show(config.tools)} placeholder="Tidak ada" readOnly /></Field>
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Workflow ID"><input className={inputCls()} value={show(config.workflowId)} placeholder="Kosong" readOnly /></Field>
              <Field label="Workflow config"><input className={inputCls()} value={show(config.workflowConfig)} placeholder="Kosong" readOnly /></Field>
              <Field label="Memory config"><input className={inputCls()} value={show(config.memoryConfig)} placeholder="Kosong" readOnly /></Field>
            </div>
          </fieldset>
        )}
      </Section>

      <Section title={emp.archived ? 'Aktifkan kembali' : 'Arsipkan'}>
        <p className="mb-3 text-sm text-slate-600">
          {emp.archived
            ? 'Karyawan akan muncul lagi di kantor (di area santai) dan bisa menerima pesan serta tugas.'
            : 'Karyawan disembunyikan dari kantor dan melepaskan mejanya. Percakapan dan tugas tetap tersimpan.'}
        </p>
        {emp.archived ? (
          <Button onClick={toggleArchive} loading={busy}><IconRestore size={15} /> Aktifkan kembali</Button>
        ) : (
          <Button onClick={() => setConfirm(true)}><IconArchive size={15} /> Arsipkan karyawan</Button>
        )}
      </Section>

      <EmployeeFormModal open={editOpen} onClose={() => setEditOpen(false)} employee={emp} />
      <ConfirmModal
        open={confirm}
        title={`Arsipkan ${emp.name}?`}
        message="Karyawan akan disembunyikan dari kantor dan mejanya dikosongkan. Anda bisa mengaktifkannya kembali kapan saja."
        confirmLabel="Arsipkan"
        busy={busy}
        onConfirm={toggleArchive}
        onClose={() => setConfirm(false)}
      />
    </div>
  );
}
