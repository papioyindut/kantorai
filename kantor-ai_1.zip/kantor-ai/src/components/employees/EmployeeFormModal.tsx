import { useEffect, useState, type FormEvent } from 'react';
import { ACCESSORIES, HAIR_STYLES, LIMITS, type AvatarConfig, type Employee } from '../../../shared/types';
import { api, ApiError } from '../../api/client';
import { ACCESSORY_LABEL, HAIR_COLORS, HAIR_LABEL, IDENTITY_COLORS, SKIN_TONES } from '../../lib/labels';
import { useData } from '../../state/DataContext';
import { AvatarIcon } from '../office/PixelAvatar';
import { Button, cx, Field, inputCls, Modal } from '../ui/ui';

interface FormState {
  name: string;
  role: string;
  description: string;
  color: string;
  avatar: AvatarConfig;
  deskId: string;
}

const randomPick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];

function initial(emp?: Employee | null): FormState {
  if (emp)
    return { name: emp.name, role: emp.role, description: emp.description, color: emp.color, avatar: emp.avatar, deskId: emp.deskId ?? '' };
  return {
    name: '',
    role: '',
    description: '',
    color: randomPick(IDENTITY_COLORS),
    avatar: { skin: randomPick(SKIN_TONES), hair: randomPick(HAIR_STYLES), hairColor: randomPick(HAIR_COLORS), accessory: 'none' },
    deskId: '',
  };
}

function Swatches({ colors, value, onChange, label }: { colors: string[]; value: string; onChange: (c: string) => void; label: string }) {
  return (
    <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label={label}>
      {colors.map((c) => (
        <button
          key={c}
          type="button"
          role="radio"
          aria-checked={value === c}
          aria-label={c}
          onClick={() => onChange(c)}
          className={cx('size-6 rounded-md ring-offset-2 transition', value === c ? 'ring-2 ring-ink-900' : 'ring-1 ring-black/10 hover:scale-110')}
          style={{ background: c }}
        />
      ))}
    </div>
  );
}

function Chips<T extends string>({ items, labels, value, onChange, label }: { items: readonly T[]; labels: Record<T, string>; value: T; onChange: (v: T) => void; label: string }) {
  return (
    <div className="flex flex-wrap gap-1.5" role="radiogroup" aria-label={label}>
      {items.map((i) => (
        <button
          key={i}
          type="button"
          role="radio"
          aria-checked={value === i}
          onClick={() => onChange(i)}
          className={cx(
            'rounded-md px-2 py-1 text-xs font-medium ring-1 transition',
            value === i ? 'bg-ink-900 text-white ring-ink-900' : 'bg-white text-ink-700 ring-line hover:bg-paper-2',
          )}
        >
          {labels[i]}
        </button>
      ))}
    </div>
  );
}

export function EmployeeFormModal({
  open,
  onClose,
  employee,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  employee?: Employee | null;
  onSaved?: (e: Employee) => void;
}) {
  const { desks, toast, reloadEmployees, employeeById } = useData();
  const [f, setF] = useState<FormState>(() => initial(employee));
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setF(initial(employee));
      setErrors({});
      setFormError(null);
    }
  }, [open, employee]);

  const set = <K extends keyof FormState>(k: K, v: FormState[K]) => setF((s) => ({ ...s, [k]: v }));
  const setAv = <K extends keyof AvatarConfig>(k: K, v: AvatarConfig[K]) => setF((s) => ({ ...s, avatar: { ...s.avatar, [k]: v } }));

  function validate(): Record<string, string> {
    const e: Record<string, string> = {};
    if (!f.name.trim()) e.name = 'Nama wajib diisi.';
    else if (f.name.trim().length > LIMITS.name) e.name = `Maksimal ${LIMITS.name} karakter.`;
    if (!f.role.trim()) e.role = 'Jabatan wajib diisi.';
    else if (f.role.trim().length > LIMITS.role) e.role = `Maksimal ${LIMITS.role} karakter.`;
    if (f.description.length > LIMITS.description) e.description = `Maksimal ${LIMITS.description} karakter.`;
    return e;
  }

  async function submit(ev: FormEvent) {
    ev.preventDefault();
    const e = validate();
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    setFormError(null);
    const payload = {
      name: f.name.trim(),
      role: f.role.trim(),
      description: f.description.trim(),
      color: f.color,
      avatar: f.avatar,
      deskId: f.deskId || null,
    };
    try {
      const saved = employee ? await api.updateEmployee(employee.id, payload) : await api.createEmployee(payload);
      await reloadEmployees();
      toast(employee ? 'Perubahan disimpan.' : `${saved.name} bergabung ke kantor.`);
      onSaved?.(saved);
      onClose();
    } catch (err) {
      if (err instanceof ApiError && err.details) setErrors(err.details);
      setFormError(err instanceof Error ? err.message : 'Gagal menyimpan.');
    } finally {
      setBusy(false);
    }
  }

  const archived = employee?.archived;

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={employee ? `Edit ${employee.name}` : 'Tambah karyawan AI'}
      width="max-w-2xl"
      footer={
        <>
          <Button onClick={onClose}>Batal</Button>
          <Button variant="primary" type="submit" form="employee-form" loading={busy}>
            {employee ? 'Simpan perubahan' : 'Tambah karyawan'}
          </Button>
        </>
      }
    >
      <form id="employee-form" onSubmit={submit} className="grid gap-5 md:grid-cols-[1fr_220px]" noValidate>
        <div className="space-y-4">
          {formError && <div className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700 ring-1 ring-red-200">{formError}</div>}
          <Field label="Nama" htmlFor="emp-name" error={errors.name} counter={`${f.name.length}/${LIMITS.name}`}>
            <input id="emp-name" className={inputCls(errors.name)} value={f.name} maxLength={LIMITS.name} onChange={(e) => set('name', e.target.value)} placeholder="mis. Nara" autoFocus />
          </Field>
          <Field label="Jabatan" htmlFor="emp-role" error={errors.role} counter={`${f.role.length}/${LIMITS.role}`}>
            <input id="emp-role" className={inputCls(errors.role)} value={f.role} maxLength={LIMITS.role} onChange={(e) => set('role', e.target.value)} placeholder="mis. Analyst" />
          </Field>
          <Field label="Deskripsi" htmlFor="emp-desc" error={errors.description} counter={`${f.description.length}/${LIMITS.description}`} hint="Catatan untuk Anda. Bukan instruksi kerja AI — itu disetup pada tahap berikutnya.">
            <textarea id="emp-desc" rows={3} className={inputCls(errors.description)} value={f.description} maxLength={LIMITS.description} onChange={(e) => set('description', e.target.value)} />
          </Field>
          <Field label="Meja" htmlFor="emp-desk" error={errors.deskId} hint={archived ? 'Aktifkan kembali karyawan untuk memilih meja.' : 'Meja yang terisi akan dipindahkan penghuninya ke area santai.'}>
            <select id="emp-desk" className={inputCls(errors.deskId)} value={f.deskId} disabled={archived} onChange={(e) => set('deskId', e.target.value)}>
              <option value="">Tanpa meja (area santai)</option>
              {desks.map((d) => {
                const occ = d.employeeId && d.employeeId !== employee?.id ? employeeById(d.employeeId) : undefined;
                return (
                  <option key={d.id} value={d.id}>
                    {d.label}
                    {occ ? ` — ditempati ${occ.name}` : ' — kosong'}
                  </option>
                );
              })}
            </select>
          </Field>
        </div>

        <div className="space-y-4 rounded-xl bg-paper p-4 ring-1 ring-line">
          <div className="flex flex-col items-center gap-2">
            <AvatarIcon avatar={f.avatar} color={f.color} size={96} className="pixel" />
            <div className="text-center text-sm font-semibold">{f.name || 'Nama'}</div>
            <div className="-mt-2 text-center text-xs text-slate-500">{f.role || 'Jabatan'}</div>
          </div>
          <Field label="Warna identitas">
            <Swatches label="Warna identitas" colors={IDENTITY_COLORS} value={f.color} onChange={(c) => set('color', c)} />
          </Field>
          <Field label="Warna kulit">
            <Swatches label="Warna kulit" colors={SKIN_TONES} value={f.avatar.skin} onChange={(c) => setAv('skin', c)} />
          </Field>
          <Field label="Rambut">
            <Chips label="Gaya rambut" items={HAIR_STYLES} labels={HAIR_LABEL} value={f.avatar.hair} onChange={(v) => setAv('hair', v)} />
          </Field>
          <Field label="Warna rambut">
            <Swatches label="Warna rambut" colors={HAIR_COLORS} value={f.avatar.hairColor} onChange={(c) => setAv('hairColor', c)} />
          </Field>
          <Field label="Aksesori">
            <Chips label="Aksesori" items={ACCESSORIES} labels={ACCESSORY_LABEL} value={f.avatar.accessory} onChange={(v) => setAv('accessory', v)} />
          </Field>
        </div>
      </form>
    </Modal>
  );
}
