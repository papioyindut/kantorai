import { useEffect, useId, type ButtonHTMLAttributes, type ReactNode } from 'react';
import type { ActivityStatus, ConfigStatus } from '../../../shared/types';
import { ACTIVITY_COLOR, ACTIVITY_LABEL, CONFIG_LABEL } from '../../lib/labels';
import { useData } from '../../state/DataContext';
import { IconX } from './icons';

export function cx(...parts: (string | false | null | undefined)[]) {
  return parts.filter(Boolean).join(' ');
}

/* ------------------------------- Button ------------------------------- */
type Variant = 'primary' | 'secondary' | 'ghost' | 'danger';
const VARIANT: Record<Variant, string> = {
  primary: 'bg-ink-900 text-white hover:bg-ink-700 disabled:bg-ink-600/50',
  secondary: 'bg-white text-ink-900 border border-line hover:bg-paper-2 disabled:text-slate-400',
  ghost: 'text-ink-700 hover:bg-ink-900/5 disabled:text-slate-400',
  danger: 'bg-red-600 text-white hover:bg-red-700 disabled:bg-red-300',
};

export function Button({
  variant = 'secondary',
  size = 'md',
  className,
  loading,
  children,
  ...rest
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: 'sm' | 'md'; loading?: boolean }) {
  return (
    <button
      type="button"
      {...rest}
      disabled={rest.disabled || loading}
      className={cx(
        'inline-flex items-center justify-center gap-1.5 rounded-lg font-medium transition-colors disabled:cursor-not-allowed focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand',
        size === 'sm' ? 'h-8 px-2.5 text-[13px]' : 'h-9 px-3.5 text-sm',
        VARIANT[variant],
        className,
      )}
    >
      {loading && <Spinner className="size-3.5" />}
      {children}
    </button>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <span className={cx('inline-block animate-spin rounded-full border-2 border-current border-r-transparent', className ?? 'size-4')} />;
}

/* ------------------------------- Badges ------------------------------- */
export function StatusDot({ status, className }: { status: ActivityStatus; className?: string }) {
  return (
    <span
      className={cx('inline-block size-2 shrink-0 rounded-full', status === 'working' && 'vo-pulse', className)}
      style={{ background: ACTIVITY_COLOR[status] }}
    />
  );
}

export function ActivityBadge({ status }: { status: ActivityStatus }) {
  return (
    <span className="inline-flex items-center gap-1.5 rounded-full bg-white px-2 py-0.5 text-xs font-medium text-ink-700 ring-1 ring-line">
      <StatusDot status={status} />
      {ACTIVITY_LABEL[status]}
    </span>
  );
}

export function ConfigBadge({ status }: { status: ConfigStatus }) {
  return status === 'ready' ? (
    <span className="inline-flex items-center rounded-full bg-emerald-50 px-2 py-0.5 text-xs font-medium text-emerald-700 ring-1 ring-emerald-200">
      {CONFIG_LABEL.ready}
    </span>
  ) : (
    <span className="inline-flex items-center rounded-full bg-amber-50 px-2 py-0.5 text-xs font-medium text-amber-800 ring-1 ring-amber-200">
      {CONFIG_LABEL.unconfigured}
    </span>
  );
}

export function SoonBadge({ children = 'Tahap berikutnya' }: { children?: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-slate-500">
      {children}
    </span>
  );
}

/* ------------------------------ Callouts ------------------------------ */
export function Callout({ tone = 'info', title, children, action }: { tone?: 'info' | 'warn'; title?: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div
      className={cx(
        'flex items-start gap-3 rounded-xl px-3.5 py-2.5 text-sm',
        tone === 'warn' ? 'bg-amber-50 text-amber-900 ring-1 ring-amber-200' : 'bg-sky-50 text-sky-900 ring-1 ring-sky-200',
      )}
    >
      <div className="min-w-0 flex-1">
        {title && <div className="font-semibold">{title}</div>}
        {children && <div className={cx(title && 'mt-0.5', 'opacity-90')}>{children}</div>}
      </div>
      {action}
    </div>
  );
}

export function EmptyState({ title, children, action, icon }: { title: string; children?: ReactNode; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-2xl border border-dashed border-line bg-white/60 px-6 py-10 text-center">
      {icon && <div className="text-slate-400">{icon}</div>}
      <div className="font-semibold text-ink-800">{title}</div>
      {children && <div className="max-w-sm text-sm text-slate-500">{children}</div>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={cx('animate-pulse rounded-lg bg-ink-900/8', className)} />;
}

/* ------------------------------- Forms -------------------------------- */
export function Field({
  label,
  error,
  hint,
  children,
  htmlFor,
  counter,
}: {
  label: string;
  error?: string;
  hint?: ReactNode;
  children: ReactNode;
  htmlFor?: string;
  counter?: string;
}) {
  return (
    <div className="space-y-1">
      <div className="flex items-baseline justify-between">
        <label htmlFor={htmlFor} className="text-[13px] font-medium text-ink-800">
          {label}
        </label>
        {counter && <span className="text-[11px] text-slate-400">{counter}</span>}
      </div>
      {children}
      {error ? <p className="text-xs text-red-600">{error}</p> : hint ? <p className="text-xs text-slate-500">{hint}</p> : null}
    </div>
  );
}

export const inputCls = (err?: string) =>
  cx(
    'w-full rounded-lg border bg-white px-3 py-2 text-sm text-ink-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 disabled:bg-slate-50 disabled:text-slate-500',
    err ? 'border-red-400 focus:ring-red-200' : 'border-line focus:border-ink-600 focus:ring-brand/40',
  );

/* ------------------------------- Modal -------------------------------- */
export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  width = 'max-w-lg',
}: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  width?: string;
}) {
  const id = useId();
  useEffect(() => {
    if (!open) return;
    const on = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', on);
    return () => window.removeEventListener('keydown', on);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/40 p-4" onMouseDown={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={id}
        className={cx('vo-fade-in flex max-h-[90vh] w-full flex-col overflow-hidden rounded-2xl bg-white shadow-2xl', width)}
        onMouseDown={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between border-b border-line px-5 py-3.5">
          <h2 id={id} className="text-base font-semibold">
            {title}
          </h2>
          <button type="button" onClick={onClose} className="rounded-md p-1 text-slate-500 hover:bg-slate-100" aria-label="Tutup">
            <IconX />
          </button>
        </div>
        <div className="thin-scroll flex-1 overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-line bg-paper/60 px-5 py-3">{footer}</div>}
      </div>
    </div>
  );
}

export function ConfirmModal({
  open,
  title,
  message,
  confirmLabel,
  danger,
  onConfirm,
  onClose,
  busy,
}: {
  open: boolean;
  title: string;
  message: ReactNode;
  confirmLabel: string;
  danger?: boolean;
  onConfirm: () => void;
  onClose: () => void;
  busy?: boolean;
}) {
  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      width="max-w-md"
      footer={
        <>
          <Button onClick={onClose}>Batal</Button>
          <Button variant={danger ? 'danger' : 'primary'} onClick={onConfirm} loading={busy}>
            {confirmLabel}
          </Button>
        </>
      }
    >
      <div className="text-sm text-slate-600">{message}</div>
    </Modal>
  );
}

/* ------------------------------- Tabs --------------------------------- */
export function Tabs<T extends string>({
  tabs,
  value,
  onChange,
}: {
  tabs: { id: T; label: string; badge?: ReactNode }[];
  value: T;
  onChange: (t: T) => void;
}) {
  return (
    <div role="tablist" className="flex gap-1 border-b border-line px-5">
      {tabs.map((t) => (
        <button
          key={t.id}
          role="tab"
          type="button"
          aria-selected={value === t.id}
          onClick={() => onChange(t.id)}
          className={cx(
            '-mb-px flex items-center gap-1.5 border-b-2 px-3 py-2.5 text-sm font-medium transition-colors',
            value === t.id ? 'border-ink-900 text-ink-900' : 'border-transparent text-slate-500 hover:text-ink-800',
          )}
        >
          {t.label}
          {t.badge}
        </button>
      ))}
    </div>
  );
}

/* ------------------------------- Toasts ------------------------------- */
export function Toasts() {
  const { toasts, dismissToast } = useData();
  return (
    <div className="pointer-events-none fixed bottom-4 right-4 z-[60] flex w-80 flex-col gap-2" aria-live="polite">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={cx(
            'vo-fade-in pointer-events-auto flex items-start gap-2 rounded-xl px-3.5 py-2.5 text-sm shadow-lg ring-1',
            t.kind === 'error' && 'bg-red-50 text-red-800 ring-red-200',
            t.kind === 'success' && 'bg-ink-900 text-white ring-ink-700',
            t.kind === 'info' && 'bg-white text-ink-900 ring-line',
          )}
        >
          <span className="flex-1">{t.text}</span>
          <button type="button" className="opacity-60 hover:opacity-100" onClick={() => dismissToast(t.id)} aria-label="Tutup notifikasi">
            <IconX size={14} />
          </button>
        </div>
      ))}
    </div>
  );
}
