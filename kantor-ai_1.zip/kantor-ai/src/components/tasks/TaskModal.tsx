import { useEffect, useState, type FormEvent } from 'react';
import { LIMITS, TASK_PRIORITIES, TASK_STATUSES, type Task, type TaskPriority, type TaskStatus } from '../../../shared/types';
import { api, ApiError } from '../../api/client';
import { formatDateTime, PRIORITY_LABEL, TASK_STATUS_LABEL } from '../../lib/labels';
import { useData } from '../../state/DataContext';
import { IconTrash } from '../ui/icons';
import { Button, Callout, ConfirmModal, Field, inputCls, Modal } from '../ui/ui';

interface Form {
  title: string;
  description: string;
  assigneeId: string;
  status: TaskStatus;
  priority: TaskPriority;
}

export function TaskModal({
  open,
  onClose,
  task,
  defaults,
  onSaved,
}: {
  open: boolean;
  onClose: () => void;
  task?: Task | null;
  defaults?: Partial<Form>;
  onSaved?: (t: Task) => void;
}) {
  const { employees, toast, toastError, bumpTasks, employeeById } = useData();
  const [f, setF] = useState<Form>({ title: '', description: '', assigneeId: '', status: 'backlog', priority: 'medium' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [confirmDel, setConfirmDel] = useState(false);
  const [delBusy, setDelBusy] = useState(false);

  useEffect(() => {
    if (!open) return;
    setErrors({});
    setF(
      task
        ? { title: task.title, description: task.description, assigneeId: task.assigneeId ?? '', status: task.status, priority: task.priority }
        : { title: '', description: '', assigneeId: '', status: 'backlog', priority: 'medium', ...defaults },
    );
  }, [open, task]);

  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((s) => ({ ...s, [k]: v }));
  const active = employees.filter((e) => !e.archived || e.id === task?.assigneeId);

  async function submit(ev: FormEvent) {
    ev.preventDefault();
    const e: Record<string, string> = {};
    if (!f.title.trim()) e.title = 'Judul wajib diisi.';
    else if (f.title.trim().length > LIMITS.taskTitle) e.title = `Maksimal ${LIMITS.taskTitle} karakter.`;
    if (f.description.length > LIMITS.taskDescription) e.description = `Maksimal ${LIMITS.taskDescription} karakter.`;
    setErrors(e);
    if (Object.keys(e).length) return;
    setBusy(true);
    try {
      const payload = { title: f.title.trim(), description: f.description.trim(), assigneeId: f.assigneeId || null, status: f.status, priority: f.priority };
      const res = task ? await api.updateTask(task.id, payload) : await api.createTask(payload);
      bumpTasks();
      toast(task ? 'Tugas diperbarui.' : 'Tugas dibuat.');
      if (res.workflow && !res.workflow.started) {
        const who = employeeById(res.task.assigneeId)?.name ?? 'AI';
        toast(`Ditugaskan ke ${who}. ${res.workflow.reason}`, 'info');
      }
      onSaved?.(res.task);
      onClose();
    } catch (err) {
      if (err instanceof ApiError && err.details) setErrors(err.details);
      toastError(err);
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!task) return;
    setDelBusy(true);
    try {
      await api.deleteTask(task.id);
      bumpTasks();
      toast('Tugas dihapus.');
      setConfirmDel(false);
      onClose();
    } catch (err) {
      toastError(err);
    } finally {
      setDelBusy(false);
    }
  }

  return (
    <>
      <Modal
        open={open && !confirmDel}
        onClose={onClose}
        title={task ? 'Detail tugas' : 'Tugas baru'}
        footer={
          <>
            {task && (
              <Button variant="ghost" className="mr-auto text-red-600" onClick={() => setConfirmDel(true)}>
                <IconTrash size={16} /> Hapus
              </Button>
            )}
            <Button onClick={onClose}>Batal</Button>
            <Button variant="primary" type="submit" form="task-form" loading={busy}>
              {task ? 'Simpan' : 'Buat tugas'}
            </Button>
          </>
        }
      >
        <form id="task-form" onSubmit={submit} className="space-y-4" noValidate>
          <Field label="Judul" htmlFor="task-title" error={errors.title} counter={`${f.title.length}/${LIMITS.taskTitle}`}>
            <input id="task-title" autoFocus className={inputCls(errors.title)} value={f.title} maxLength={LIMITS.taskTitle} onChange={(e) => set('title', e.target.value)} placeholder="Apa yang perlu dikerjakan?" />
          </Field>
          <Field label="Deskripsi" htmlFor="task-desc" error={errors.description}>
            <textarea id="task-desc" rows={4} className={inputCls(errors.description)} value={f.description} onChange={(e) => set('description', e.target.value)} placeholder="Detail, konteks, atau kriteria selesai (opsional)" />
          </Field>
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="Ditugaskan ke" htmlFor="task-assignee" error={errors.assigneeId}>
              <select id="task-assignee" className={inputCls(errors.assigneeId)} value={f.assigneeId} onChange={(e) => set('assigneeId', e.target.value)}>
                <option value="">Belum ditugaskan</option>
                {active.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.name} — {e.role}
                    {e.archived ? ' (diarsipkan)' : ''}
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Status" htmlFor="task-status">
              <select id="task-status" className={inputCls()} value={f.status} onChange={(e) => set('status', e.target.value as TaskStatus)}>
                {TASK_STATUSES.map((s) => (
                  <option key={s} value={s}>{TASK_STATUS_LABEL[s]}</option>
                ))}
              </select>
            </Field>
            <Field label="Prioritas" htmlFor="task-priority">
              <select id="task-priority" className={inputCls()} value={f.priority} onChange={(e) => set('priority', e.target.value as TaskPriority)}>
                {TASK_PRIORITIES.map((p) => (
                  <option key={p} value={p}>{PRIORITY_LABEL[p]}</option>
                ))}
              </select>
            </Field>
          </div>
          {f.assigneeId && (
            <Callout title="Tugas dikelola manual">
              Menugaskan tugas ke karyawan AI belum menjalankan workflow pada tahap ini. Status diperbarui oleh Anda.
            </Callout>
          )}
          {task && (
            <div className="flex flex-wrap gap-x-6 gap-y-1 text-xs text-slate-500">
              <span>Dibuat: {formatDateTime(task.createdAt)}</span>
              <span>Diperbarui: {formatDateTime(task.updatedAt)}</span>
            </div>
          )}
        </form>
      </Modal>
      <ConfirmModal
        open={confirmDel}
        title="Hapus tugas?"
        message={<>Tugas “{task?.title}” akan dihapus permanen dan tidak bisa dikembalikan.</>}
        confirmLabel="Hapus permanen"
        danger
        busy={delBusy}
        onConfirm={remove}
        onClose={() => setConfirmDel(false)}
      />
    </>
  );
}
