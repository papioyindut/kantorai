import type { DragEvent } from 'react';
import type { Task } from '../../../shared/types';
import { PRIORITY_LABEL, PRIORITY_STYLE, relativeTime, formatDateTime } from '../../lib/labels';
import { useData } from '../../state/DataContext';
import { AvatarIcon } from '../office/PixelAvatar';
import { cx } from '../ui/ui';

export function TaskCard({ task, onOpen, draggable, onDragStart, dragging }: { task: Task; onOpen: () => void; draggable?: boolean; onDragStart?: (e: DragEvent) => void; dragging?: boolean }) {
  const { employeeById } = useData();
  const emp = employeeById(task.assigneeId);
  return (
    <button
      type="button"
      onClick={onOpen}
      draggable={draggable}
      onDragStart={onDragStart}
      data-testid="task-card"
      data-task-id={task.id}
      className={cx(
        'w-full rounded-xl bg-white p-3 text-left shadow-sm ring-1 ring-line transition hover:-translate-y-px hover:shadow-md focus-visible:outline-2 focus-visible:outline-brand',
        dragging && 'opacity-40',
      )}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="line-clamp-2 text-sm font-semibold text-ink-900">{task.title}</div>
        <span className={cx('shrink-0 rounded px-1.5 py-0.5 text-[10px] font-semibold', PRIORITY_STYLE[task.priority])}>{PRIORITY_LABEL[task.priority]}</span>
      </div>
      {task.description && <p className="mt-1 line-clamp-2 text-xs text-slate-500">{task.description}</p>}
      <div className="mt-2.5 flex items-center justify-between gap-2">
        {emp ? (
          <span className="flex min-w-0 items-center gap-1.5 text-xs text-ink-700">
            <AvatarIcon avatar={emp.avatar} color={emp.color} size={20} />
            <span className="truncate">{emp.name}</span>
          </span>
        ) : (
          <span className="text-xs text-slate-400">Belum ditugaskan</span>
        )}
        <span className="shrink-0 text-[11px] text-slate-400" title={`Dibuat ${formatDateTime(task.createdAt)}`}>
          {relativeTime(task.createdAt)}
        </span>
      </div>
    </button>
  );
}
