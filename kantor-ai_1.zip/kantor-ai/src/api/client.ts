import type {
  AIConfig,
  AppSettings,
  ConversationSummary,
  Desk,
  Employee,
  EmployeeInput,
  Message,
  SendMessageResult,
  SystemInfo,
  Task,
  TaskInput,
  TaskMutationResult,
} from '../../shared/types';

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public details: Record<string, string> | null = null,
  ) {
    super(message);
  }
}

async function request<T>(method: string, url: string, body?: unknown): Promise<T> {
  let res: Response;
  try {
    res = await fetch(url, {
      method,
      headers: body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new ApiError(0, 'Tidak dapat terhubung ke server lokal. Pastikan `npm run dev` masih berjalan.');
  }
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    /* bukan JSON */
  }
  if (!res.ok) {
    const d = (data ?? {}) as { error?: string; details?: Record<string, string> | null };
    throw new ApiError(res.status, d.error ?? `Permintaan gagal (${res.status}).`, d.details ?? null);
  }
  return data as T;
}

export const api = {
  system: () => request<SystemInfo>('GET', '/api/system'),
  settings: () => request<AppSettings>('GET', '/api/settings'),
  updateSettings: (p: Partial<AppSettings>) => request<AppSettings>('PATCH', '/api/settings', p),

  employees: () => request<Employee[]>('GET', '/api/employees'),
  createEmployee: (p: EmployeeInput) => request<Employee>('POST', '/api/employees', p),
  updateEmployee: (id: string, p: Partial<EmployeeInput>) => request<Employee>('PATCH', `/api/employees/${id}`, p),
  archiveEmployee: (id: string) => request<Employee>('POST', `/api/employees/${id}/archive`),
  restoreEmployee: (id: string) => request<Employee>('POST', `/api/employees/${id}/restore`),
  assignDesk: (id: string, deskId: string | null) =>
    request<{ employees: Employee[]; desks: Desk[] }>('PUT', `/api/employees/${id}/desk`, { deskId }),
  config: (id: string) => request<AIConfig>('GET', `/api/employees/${id}/config`),

  desks: () => request<Desk[]>('GET', '/api/desks'),

  conversations: () => request<ConversationSummary[]>('GET', '/api/conversations'),
  messages: (employeeId: string) => request<Message[]>('GET', `/api/employees/${employeeId}/messages`),
  sendMessage: (employeeId: string, content: string) =>
    request<SendMessageResult>('POST', `/api/employees/${employeeId}/messages`, { content }),

  tasks: (assigneeId?: string) =>
    request<Task[]>('GET', assigneeId ? `/api/tasks?assigneeId=${encodeURIComponent(assigneeId)}` : '/api/tasks'),
  createTask: (p: TaskInput) => request<TaskMutationResult>('POST', '/api/tasks', p),
  updateTask: (id: string, p: Partial<TaskInput>) => request<TaskMutationResult>('PATCH', `/api/tasks/${id}`, p),
  deleteTask: (id: string) => request<{ ok: true }>('DELETE', `/api/tasks/${id}`),
};
