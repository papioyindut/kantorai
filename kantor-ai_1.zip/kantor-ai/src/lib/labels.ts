import type { Accessory, ActivityStatus, ConfigStatus, HairStyle, TaskPriority, TaskStatus } from '../../shared/types';

export const ACTIVITY_LABEL: Record<ActivityStatus, string> = {
  idle: 'Idle',
  working: 'Bekerja',
  waiting: 'Menunggu',
  error: 'Error',
  offline: 'Offline',
};

export const ACTIVITY_COLOR: Record<ActivityStatus, string> = {
  idle: '#22c55e',
  working: '#3b82f6',
  waiting: '#f59e0b',
  error: '#ef4444',
  offline: '#94a3b8',
};

export const CONFIG_LABEL: Record<ConfigStatus, string> = {
  unconfigured: 'Belum dikonfigurasi',
  ready: 'Siap',
};

export const TASK_STATUS_LABEL: Record<TaskStatus, string> = {
  backlog: 'Backlog',
  todo: 'To Do',
  in_progress: 'Dikerjakan',
  review: 'Review',
  done: 'Selesai',
};

export const TASK_STATUS_ACCENT: Record<TaskStatus, string> = {
  backlog: '#94a3b8',
  todo: '#6366f1',
  in_progress: '#3b82f6',
  review: '#f59e0b',
  done: '#22c55e',
};

export const PRIORITY_LABEL: Record<TaskPriority, string> = {
  low: 'Rendah',
  medium: 'Sedang',
  high: 'Tinggi',
  urgent: 'Mendesak',
};

export const PRIORITY_STYLE: Record<TaskPriority, string> = {
  low: 'bg-slate-100 text-slate-600',
  medium: 'bg-sky-100 text-sky-700',
  high: 'bg-orange-100 text-orange-700',
  urgent: 'bg-red-100 text-red-700',
};

export const HAIR_LABEL: Record<HairStyle, string> = {
  short: 'Pendek',
  bob: 'Bob',
  spiky: 'Jabrik',
  long: 'Panjang',
  bun: 'Cepol',
  bald: 'Plontos',
};

export const ACCESSORY_LABEL: Record<Accessory, string> = {
  none: 'Tanpa',
  glasses: 'Kacamata',
  headset: 'Headset',
  cap: 'Topi',
};

export const SKIN_TONES = ['#ffdbac', '#f1c27d', '#e0ac69', '#c68642', '#8d5524', '#5c3a1e'];
export const HAIR_COLORS = ['#111111', '#2b1d16', '#5a3825', '#8a4b2a', '#d9a441', '#d94f70', '#6b7cff', '#e5e7eb'];
export const IDENTITY_COLORS = ['#4f8cff', '#22a67a', '#e0703a', '#c254d6', '#e8b730', '#ef4f6b', '#14b8a6', '#64748b'];

const dtf = new Intl.DateTimeFormat('id-ID', { dateStyle: 'medium', timeStyle: 'short' });
const tf = new Intl.DateTimeFormat('id-ID', { hour: '2-digit', minute: '2-digit' });
const df = new Intl.DateTimeFormat('id-ID', { day: 'numeric', month: 'short' });

export function formatDateTime(iso: string) {
  return dtf.format(new Date(iso));
}

export function formatShort(iso: string) {
  const d = new Date(iso);
  const now = new Date();
  return d.toDateString() === now.toDateString() ? tf.format(d) : df.format(d);
}

export function relativeTime(iso: string) {
  const diff = (Date.now() - new Date(iso).getTime()) / 1000;
  if (diff < 60) return 'baru saja';
  if (diff < 3600) return `${Math.floor(diff / 60)} mnt lalu`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} jam lalu`;
  if (diff < 86400 * 7) return `${Math.floor(diff / 86400)} hari lalu`;
  return df.format(new Date(iso));
}
