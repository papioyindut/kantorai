import { useEffect, useState } from 'react';

// Router hash sederhana: #/office, #/messages/emp_x, #/tasks?profile=emp_x&tab=chat
export type Section = 'office' | 'employees' | 'messages' | 'tasks' | 'settings';
const SECTIONS: Section[] = ['office', 'employees', 'messages', 'tasks', 'settings'];

export interface Route {
  section: Section;
  segments: string[];
  query: URLSearchParams;
}

export function parseHash(hash: string): Route {
  const raw = hash.replace(/^#\/?/, '');
  const [path, qs = ''] = raw.split('?');
  const segs = path.split('/').filter(Boolean);
  const section = (SECTIONS as string[]).includes(segs[0]) ? (segs[0] as Section) : 'office';
  return { section, segments: segs.slice(1), query: new URLSearchParams(qs) };
}

export function buildHash(section: Section, segments: string[] = [], query?: Record<string, string | null | undefined>) {
  const q = new URLSearchParams();
  if (query) for (const [k, v] of Object.entries(query)) if (v) q.set(k, v);
  const qs = q.toString();
  return `#/${[section, ...segments].join('/')}${qs ? `?${qs}` : ''}`;
}

export function navigate(hash: string) {
  if (window.location.hash !== hash) window.location.hash = hash;
}

export function useRoute(): Route {
  const [route, setRoute] = useState(() => parseHash(window.location.hash));
  useEffect(() => {
    const on = () => setRoute(parseHash(window.location.hash));
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return route;
}

/** Buka profil karyawan (drawer) di atas halaman saat ini. */
export function openProfile(route: Route, employeeId: string, tab = 'overview') {
  const q: Record<string, string> = {};
  route.query.forEach((v, k) => (q[k] = v));
  navigate(buildHash(route.section, route.segments, { ...q, profile: employeeId, tab }));
}

export function closeProfile(route: Route) {
  const q: Record<string, string> = {};
  route.query.forEach((v, k) => {
    if (k !== 'profile' && k !== 'tab') q[k] = v;
  });
  navigate(buildHash(route.section, route.segments, q));
}
