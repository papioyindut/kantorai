import { DB_PATH, DATA_DIR } from './db/connection';
import { LATEST_SCHEMA_VERSION } from './db/migrations';
import * as repo from './db/repo';
import { HttpError, Router } from './http';
import { listProviders, listWorkflowEngines } from './runtime/registry';
import * as runtime from './runtime/service';
import { asObj, avatar, color, Errors, LIMITS, str, taskPriority, taskStatus } from './validate';
import type { AIConfig, SystemInfo } from '../shared/types';

const DEFAULT_AVATAR = { skin: '#f1c27d', hair: 'short' as const, hairColor: '#3b2a20', accessory: 'none' as const };

function mustEmployee(id: string) {
  const e = repo.getEmployee(id);
  if (!e) throw new HttpError(404, 'Karyawan tidak ditemukan.');
  return e;
}

function deskField(errs: Errors, o: Record<string, unknown>): string | null | undefined {
  if (o.deskId === undefined) return undefined;
  if (o.deskId === null || o.deskId === '') return null;
  if (typeof o.deskId !== 'string' || !repo.deskExists(o.deskId)) {
    errs.add('deskId', 'Meja tidak ditemukan.');
    return undefined;
  }
  return o.deskId;
}

function assigneeField(errs: Errors, o: Record<string, unknown>): string | null | undefined {
  if (o.assigneeId === undefined) return undefined;
  if (o.assigneeId === null || o.assigneeId === '') return null;
  const emp = typeof o.assigneeId === 'string' ? repo.getEmployee(o.assigneeId) : null;
  if (!emp) { errs.add('assigneeId', 'Karyawan tidak ditemukan.'); return undefined; }
  if (emp.archived) { errs.add('assigneeId', 'Karyawan yang diarsipkan tidak bisa ditugaskan.'); return undefined; }
  return emp.id;
}

export function buildRouter(info: { host: string; port: number; version: string }): Router {
  const r = new Router();

  r.get('/api/health', () => ({ ok: true }));

  r.get('/api/system', (): SystemInfo => ({
    version: info.version,
    dbPath: DB_PATH,
    dataDir: DATA_DIR,
    schemaVersion: LATEST_SCHEMA_VERSION,
    seededAt: repo.getMeta('seeded_at'),
    nodeVersion: process.versions.node,
    host: info.host,
    port: info.port,
    providers: listProviders().map((p) => ({ id: p.id, label: p.label, kind: p.kind })),
    workflowEngines: listWorkflowEngines().map((w) => ({ id: w.id, label: w.label })),
  }));

  /* ------------------------------ Settings ----------------------------- */
  r.get('/api/settings', () => repo.getSettings());
  r.patch('/api/settings', ({ body }) => {
    const o = asObj(body);
    const errs = new Errors();
    const officeName = str(errs, o, 'officeName', 'Nama kantor', { required: o.officeName !== undefined, max: LIMITS.officeName });
    let demoMode: boolean | undefined;
    if (o.demoMode !== undefined) {
      if (typeof o.demoMode !== 'boolean') errs.add('demoMode', 'Mode demo harus true/false.');
      else demoMode = o.demoMode;
    }
    errs.throwIfAny();
    return repo.updateSettings({ officeName, demoMode });
  });

  /* ------------------------------ Desks -------------------------------- */
  r.get('/api/desks', () => repo.listDesks());

  /* ---------------------------- Employees ------------------------------ */
  r.get('/api/employees', () => repo.listEmployees(true));
  r.get('/api/employees/:id', ({ params }) => mustEmployee(params.id));

  r.post('/api/employees', ({ body }) => {
    const o = asObj(body);
    const errs = new Errors();
    const name = str(errs, o, 'name', 'Nama', { required: true, max: LIMITS.name });
    const role = str(errs, o, 'role', 'Jabatan', { required: true, max: LIMITS.role });
    const description = str(errs, o, 'description', 'Deskripsi', { max: LIMITS.description }) ?? '';
    const av = avatar(errs, o) ?? DEFAULT_AVATAR;
    const c = color(errs, o, 'color') ?? '#4f8cff';
    const deskId = deskField(errs, o) ?? null;
    errs.throwIfAny();
    return repo.createEmployee({ name: name!, role: role!, description, avatar: av, color: c, deskId });
  });

  r.patch('/api/employees/:id', ({ params, body }) => {
    const cur = mustEmployee(params.id);
    const o = asObj(body);
    const errs = new Errors();
    const patch = {
      name: str(errs, o, 'name', 'Nama', { required: o.name !== undefined, max: LIMITS.name }),
      role: str(errs, o, 'role', 'Jabatan', { required: o.role !== undefined, max: LIMITS.role }),
      description: str(errs, o, 'description', 'Deskripsi', { max: LIMITS.description }),
      avatar: avatar(errs, o),
      color: color(errs, o, 'color'),
      deskId: deskField(errs, o),
    };
    if (patch.deskId && cur.archived) errs.add('deskId', 'Aktifkan kembali karyawan sebelum menempatkan di meja.');
    errs.throwIfAny();
    return repo.updateEmployee(cur.id, patch);
  });

  r.put('/api/employees/:id/desk', ({ params, body }) => {
    const cur = mustEmployee(params.id);
    const errs = new Errors();
    const deskId = deskField(errs, asObj(body));
    if (deskId && cur.archived) errs.add('deskId', 'Aktifkan kembali karyawan sebelum menempatkan di meja.');
    errs.throwIfAny();
    repo.assignDesk(cur.id, deskId ?? null);
    return { employees: repo.listEmployees(true), desks: repo.listDesks() };
  });

  r.post('/api/employees/:id/archive', ({ params }) => repo.setArchived(mustEmployee(params.id).id, true));
  r.post('/api/employees/:id/restore', ({ params }) => repo.setArchived(mustEmployee(params.id).id, false));

  /* ---------------------- AI config (tahap berikut) -------------------- */
  r.get('/api/employees/:id/config', ({ params }) => repo.getConfig(mustEmployee(params.id).id));
  r.patch('/api/employees/:id/config', ({ params, body }) => {
    const emp = mustEmployee(params.id);
    const o = asObj(body);
    const patch: Partial<Omit<AIConfig, 'employeeId' | 'updatedAt'>> = {};
    const nullableStr = (k: 'systemPrompt' | 'provider' | 'model' | 'workflowId') => {
      if (o[k] === undefined) return;
      if (o[k] !== null && typeof o[k] !== 'string') throw new HttpError(422, `${k} harus teks atau null.`);
      patch[k] = (o[k] as string | null) || null;
    };
    nullableStr('systemPrompt');
    nullableStr('provider');
    nullableStr('model');
    nullableStr('workflowId');
    if (o.tools !== undefined) {
      if (!Array.isArray(o.tools) || o.tools.some((t) => typeof t !== 'string')) throw new HttpError(422, 'tools harus array teks.');
      patch.tools = o.tools as string[];
    }
    for (const k of ['workflowConfig', 'memoryConfig'] as const) {
      if (o[k] === undefined) continue;
      if (o[k] !== null && (typeof o[k] !== 'object' || Array.isArray(o[k]))) throw new HttpError(422, `${k} harus objek atau null.`);
      patch[k] = o[k] as Record<string, unknown> | null;
    }
    return repo.updateConfig(emp.id, patch);
  });

  /* ---------------------------- Messenger ------------------------------ */
  r.get('/api/conversations', () => repo.listConversationSummaries());
  r.get('/api/employees/:id/messages', ({ params }) => repo.listMessages(mustEmployee(params.id).id));
  r.post('/api/employees/:id/messages', async ({ params, body }) => {
    const emp = mustEmployee(params.id);
    if (emp.archived) throw new HttpError(409, 'Karyawan diarsipkan. Aktifkan kembali untuk mengirim pesan.');
    const errs = new Errors();
    const content = str(errs, asObj(body), 'content', 'Pesan', { required: true, max: LIMITS.message });
    errs.throwIfAny();
    return runtime.handleUserMessage(emp, content!);
  });

  /* ------------------------------ Tasks -------------------------------- */
  r.get('/api/tasks', ({ query }) => repo.listTasks({ assigneeId: query.get('assigneeId') ?? undefined }));
  r.get('/api/tasks/:id', ({ params }) => {
    const t = repo.getTask(params.id);
    if (!t) throw new HttpError(404, 'Tugas tidak ditemukan.');
    return t;
  });
  r.post('/api/tasks', async ({ body }) => {
    const o = asObj(body);
    const errs = new Errors();
    const title = str(errs, o, 'title', 'Judul', { required: true, max: LIMITS.taskTitle });
    const description = str(errs, o, 'description', 'Deskripsi', { max: LIMITS.taskDescription }) ?? '';
    const assigneeId = assigneeField(errs, o) ?? null;
    const status = taskStatus(errs, o) ?? 'backlog';
    const priority = taskPriority(errs, o) ?? 'medium';
    errs.throwIfAny();
    const task = repo.createTask({ title: title!, description, assigneeId, status, priority });
    return runtime.onTaskAssigned(task, null);
  });
  r.patch('/api/tasks/:id', async ({ params, body }) => {
    const cur = repo.getTask(params.id);
    if (!cur) throw new HttpError(404, 'Tugas tidak ditemukan.');
    const o = asObj(body);
    const errs = new Errors();
    const patch = {
      title: str(errs, o, 'title', 'Judul', { required: o.title !== undefined, max: LIMITS.taskTitle }),
      description: str(errs, o, 'description', 'Deskripsi', { max: LIMITS.taskDescription }),
      assigneeId: assigneeField(errs, o),
      status: taskStatus(errs, o),
      priority: taskPriority(errs, o),
    };
    errs.throwIfAny();
    const clean = Object.fromEntries(Object.entries(patch).filter(([, v]) => v !== undefined));
    const task = repo.updateTask(cur.id, clean);
    return runtime.onTaskAssigned(task, cur.assigneeId);
  });
  r.delete('/api/tasks/:id', ({ params }) => {
    if (!repo.deleteTask(params.id)) throw new HttpError(404, 'Tugas tidak ditemukan.');
    return { ok: true };
  });

  r.get('/api/export', ({ res }) => {
    res.setHeader('Content-Disposition', 'attachment; filename="kantor-ai-export.json"');
    return repo.exportAll();
  });

  return r;
}
