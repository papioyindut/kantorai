import { createServer } from 'node:http';
import { existsSync, readFileSync, statSync } from 'node:fs';
import path from 'node:path';
import { DB_PATH, PROJECT_ROOT, closeDb, getDb } from './db/connection';
import { runMigrations } from './db/migrations';
import { ensureDesks, seedOnce } from './db/seed';
import { sendJson } from './http';
import { buildRouter } from './routes';

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`[kantor-ai] Butuh Node.js >= 22.13 untuk modul node:sqlite (terpasang: ${process.versions.node}).`);
  process.exit(1);
}

// Default hanya koneksi lokal. Ubah lewat env VO_HOST bila benar-benar perlu.
const HOST = process.env.VO_HOST ?? '127.0.0.1';
const PORT = Number(process.env.VO_PORT ?? 5174);
const SERVE_DIST = process.argv.includes('--serve-dist');
const DIST = path.join(PROJECT_ROOT, 'dist');
const VERSION = '0.1.0';

getDb();
runMigrations();
ensureDesks();
seedOnce();

const router = buildRouter({ host: HOST, port: PORT, version: VERSION });

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json',
  '.woff2': 'font/woff2',
};

function serveStatic(pathname: string, res: import('node:http').ServerResponse): boolean {
  if (!SERVE_DIST || !existsSync(DIST)) return false;
  const safe = path.normalize(decodeURIComponent(pathname)).replace(/^([/\\])+/, '');
  let file = path.join(DIST, safe);
  if (!file.startsWith(DIST)) return false;
  if (!existsSync(file) || statSync(file).isDirectory()) file = path.join(DIST, 'index.html'); // SPA fallback
  const ext = path.extname(file);
  res.writeHead(200, {
    'Content-Type': MIME[ext] ?? 'application/octet-stream',
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=3600',
  });
  res.end(readFileSync(file));
  return true;
}

const server = createServer(async (req, res) => {
  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
  if (url.pathname.startsWith('/api/')) {
    const handled = await router.handle(req, res, url.pathname, url.searchParams);
    if (!handled) sendJson(res, 404, { error: 'Endpoint tidak ditemukan.' });
    return;
  }
  if (req.method === 'GET' && serveStatic(url.pathname, res)) return;
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end(SERVE_DIST ? 'Build belum ada. Jalankan `npm run build`.' : 'API Kantor AI. Buka frontend di http://localhost:5173');
});

server.listen(PORT, HOST, () => {
  console.log(`[kantor-ai] API berjalan di http://${HOST}:${PORT}`);
  if (SERVE_DIST) console.log(`[kantor-ai] Aplikasi: http://127.0.0.1:${PORT}`);
  console.log(`[kantor-ai] Database: ${DB_PATH}`);
});

function shutdown() {
  server.close();
  closeDb();
  process.exit(0);
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
