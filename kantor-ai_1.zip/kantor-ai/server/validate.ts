// Validasi input sederhana (pesan error berbahasa Indonesia).
import {
  ACCESSORIES,
  HAIR_STYLES,
  LIMITS,
  TASK_PRIORITIES,
  TASK_STATUSES,
  type AvatarConfig,
  type TaskPriority,
  type TaskStatus,
} from '../shared/types';
import { HttpError } from './http';

export type Obj = Record<string, unknown>;

export function asObj(v: unknown): Obj {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new HttpError(400, 'Body harus berupa objek JSON.');
  return v as Obj;
}

const HEX = /^#[0-9a-fA-F]{6}$/;

export class Errors {
  e: Record<string, string> = {};
  add(field: string, msg: string) { this.e[field] = msg; }
  throwIfAny() {
    if (Object.keys(this.e).length) throw new HttpError(422, 'Data tidak valid.', this.e);
  }
}

export function str(errs: Errors, o: Obj, key: string, label: string, opts: { required?: boolean; max: number }): string | undefined {
  const v = o[key];
  if (v === undefined) {
    if (opts.required) errs.add(key, `${label} wajib diisi.`);
    return undefined;
  }
  if (typeof v !== 'string') { errs.add(key, `${label} harus berupa teks.`); return undefined; }
  const t = v.trim();
  if (opts.required && !t) { errs.add(key, `${label} wajib diisi.`); return undefined; }
  if (t.length > opts.max) { errs.add(key, `${label} maksimal ${opts.max} karakter.`); return undefined; }
  return t;
}

export function color(errs: Errors, o: Obj, key: string): string | undefined {
  const v = o[key];
  if (v === undefined) return undefined;
  if (typeof v !== 'string' || !HEX.test(v)) { errs.add(key, 'Warna harus format hex, mis. #4f8cff.'); return undefined; }
  return v.toLowerCase();
}

export function avatar(errs: Errors, o: Obj): AvatarConfig | undefined {
  const v = o.avatar;
  if (v === undefined) return undefined;
  if (!v || typeof v !== 'object') { errs.add('avatar', 'Avatar tidak valid.'); return undefined; }
  const a = v as Obj;
  const ok =
    typeof a.skin === 'string' && HEX.test(a.skin) &&
    typeof a.hairColor === 'string' && HEX.test(a.hairColor) &&
    (HAIR_STYLES as string[]).includes(String(a.hair)) &&
    (ACCESSORIES as string[]).includes(String(a.accessory));
  if (!ok) { errs.add('avatar', 'Avatar tidak valid.'); return undefined; }
  return { skin: String(a.skin), hairColor: String(a.hairColor), hair: a.hair as AvatarConfig['hair'], accessory: a.accessory as AvatarConfig['accessory'] };
}

export function oneOf<T extends string>(errs: Errors, o: Obj, key: string, list: readonly T[], label: string): T | undefined {
  const v = o[key];
  if (v === undefined) return undefined;
  if (!(list as readonly string[]).includes(String(v))) { errs.add(key, `${label} tidak valid.`); return undefined; }
  return v as T;
}

export const taskStatus = (e: Errors, o: Obj) => oneOf<TaskStatus>(e, o, 'status', TASK_STATUSES, 'Status');
export const taskPriority = (e: Errors, o: Obj) => oneOf<TaskPriority>(e, o, 'priority', TASK_PRIORITIES, 'Prioritas');
export { LIMITS };
