import { DESK_SLOTS } from '../../shared/officeLayout';
import type { AvatarConfig } from '../../shared/types';
import { nowIso, tx } from './connection';
import * as repo from './repo';

/** Meja adalah struktur kantor: dipastikan ada setiap start (INSERT OR IGNORE, tidak menimpa). */
export function ensureDesks(): void {
  tx(() => DESK_SLOTS.forEach((d, i) => repo.insertDesk({ ...d, sortOrder: i })));
}

const SAMPLE: { name: string; role: string; description: string; color: string; avatar: AvatarConfig }[] = [
  {
    name: 'Asa',
    role: 'Assistant',
    description: 'Contoh karyawan: asisten umum. Instruksi kerja belum disetup — bebas diubah atau dihapus (arsipkan).',
    color: '#4f8cff',
    avatar: { skin: '#f1c27d', hair: 'bob', hairColor: '#2b1d16', accessory: 'headset' },
  },
  {
    name: 'Riset',
    role: 'Researcher',
    description: 'Contoh karyawan: peneliti. Peran ini hanya data awal, bukan workflow bawaan.',
    color: '#22a67a',
    avatar: { skin: '#c68642', hair: 'short', hairColor: '#1b1b1b', accessory: 'glasses' },
  },
  {
    name: 'Kata',
    role: 'Writer',
    description: 'Contoh karyawan: penulis. Konfigurasi model & workflow dilakukan pada tahap berikutnya.',
    color: '#e0703a',
    avatar: { skin: '#ffdbac', hair: 'long', hairColor: '#8a4b2a', accessory: 'none' },
  },
  {
    name: 'Rupa',
    role: 'Designer',
    description: 'Contoh karyawan: desainer. Bebas mengganti nama, jabatan, avatar, dan warna.',
    color: '#c254d6',
    avatar: { skin: '#e0ac69', hair: 'bun', hairColor: '#d94f70', accessory: 'none' },
  },
  {
    name: 'Kode',
    role: 'Developer',
    description: 'Contoh karyawan: developer. Belum memiliki akses tools atau terminal.',
    color: '#e8b730',
    avatar: { skin: '#8d5524', hair: 'spiky', hairColor: '#111111', accessory: 'cap' },
  },
];

/** Seed contoh hanya SEKALI (dijaga meta 'seeded_at'), agar perubahan pengguna tidak tertimpa. */
export function seedOnce(): { seeded: boolean; seededAt: string | null } {
  const existing = repo.getMeta('seeded_at');
  if (existing) return { seeded: false, seededAt: existing };

  const at = nowIso();
  return tx(() => seedSample(at));
}

function seedSample(at: string): { seeded: boolean; seededAt: string } {
  const created = SAMPLE.map((e, i) =>
    repo.createEmployee({ ...e, deskId: DESK_SLOTS[[0, 1, 2, 4, 5][i]].id }),
  );
  const [asa, riset, kata] = created;
  repo.createTask({
    title: 'Coba task board',
    description: 'Contoh tugas. Seret kartu ke kolom lain atau buka detail untuk mengubah status.',
    assigneeId: asa.id,
    status: 'todo',
    priority: 'medium',
  });
  repo.createTask({
    title: 'Kumpulkan referensi produk',
    description: 'Contoh tugas manual. Menugaskan ke AI belum menjalankan workflow pada tahap ini.',
    assigneeId: riset.id,
    status: 'backlog',
    priority: 'low',
  });
  repo.createTask({
    title: 'Draf halaman tentang kami',
    description: '',
    assigneeId: kata.id,
    status: 'in_progress',
    priority: 'high',
  });
  repo.updateSettings({ officeName: 'Kantor AI Saya', demoMode: false });
  repo.setMeta('seeded_at', at);
  console.log('[db] data contoh ditambahkan (sekali saja)');
  return { seeded: true, seededAt: at };
}
