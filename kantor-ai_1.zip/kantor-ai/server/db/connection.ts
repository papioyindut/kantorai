import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
export const PROJECT_ROOT = path.resolve(here, '..', '..');

/** Lokasi data: ./data (default) atau env VO_DATA_DIR. */
export const DATA_DIR = path.resolve(process.env.VO_DATA_DIR ?? path.join(PROJECT_ROOT, 'data'));
export const DB_PATH = path.join(DATA_DIR, 'virtual-office.db');

let db: DatabaseSync | null = null;

export function getDb(): DatabaseSync {
  if (db) return db;
  mkdirSync(DATA_DIR, { recursive: true });
  db = new DatabaseSync(DB_PATH);
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA busy_timeout = 3000;');
  return db;
}

export function closeDb(): void {
  if (db) {
    db.close();
    db = null;
  }
}

let txDepth = 0;

/** Menjalankan fn di dalam transaksi (re-entrant); rollback bila error. */
export function tx<T>(fn: () => T): T {
  const d = getDb();
  if (txDepth > 0) return fn();
  d.exec('BEGIN IMMEDIATE');
  txDepth++;
  try {
    const result = fn();
    txDepth--;
    d.exec('COMMIT');
    return result;
  } catch (err) {
    txDepth--;
    d.exec('ROLLBACK');
    throw err;
  }
}

export function nowIso(): string {
  return new Date().toISOString();
}

export function newId(prefix: string): string {
  return `${prefix}_${crypto.randomUUID().replace(/-/g, '').slice(0, 16)}`;
}
