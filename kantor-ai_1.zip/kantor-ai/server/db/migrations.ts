import { getDb, nowIso } from './connection';

interface Migration {
  version: number;
  name: string;
  up: string;
}

/**
 * Migrasi berversi. JANGAN mengubah migrasi yang sudah dirilis —
 * tambahkan migrasi baru dengan nomor versi berikutnya.
 */
const MIGRATIONS: Migration[] = [
  {
    version: 1,
    name: 'init',
    up: `
      CREATE TABLE meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      );

      CREATE TABLE settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE desks (
        id TEXT PRIMARY KEY,
        label TEXT NOT NULL,
        zone TEXT NOT NULL DEFAULT 'work',
        x INTEGER NOT NULL,
        y INTEGER NOT NULL,
        sort_order INTEGER NOT NULL DEFAULT 0
      );

      CREATE TABLE employees (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        role TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        avatar TEXT NOT NULL,
        color TEXT NOT NULL,
        desk_id TEXT UNIQUE REFERENCES desks(id) ON DELETE SET NULL,
        activity_status TEXT NOT NULL DEFAULT 'offline',
        archived_at TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE ai_configs (
        employee_id TEXT PRIMARY KEY REFERENCES employees(id) ON DELETE CASCADE,
        system_prompt TEXT,
        provider TEXT,
        model TEXT,
        tools TEXT NOT NULL DEFAULT '[]',
        workflow_id TEXT,
        workflow_config TEXT,
        memory_config TEXT,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE conversations (
        id TEXT PRIMARY KEY,
        employee_id TEXT NOT NULL UNIQUE REFERENCES employees(id) ON DELETE CASCADE,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE messages (
        id TEXT PRIMARY KEY,
        conversation_id TEXT NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
        sender TEXT NOT NULL CHECK (sender IN ('user','ai','system')),
        kind TEXT NOT NULL DEFAULT 'normal' CHECK (kind IN ('normal','simulation','notice')),
        content TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE INDEX idx_messages_conv ON messages(conversation_id, created_at);

      CREATE TABLE tasks (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT NOT NULL DEFAULT '',
        assignee_id TEXT REFERENCES employees(id) ON DELETE SET NULL,
        status TEXT NOT NULL DEFAULT 'backlog'
          CHECK (status IN ('backlog','todo','in_progress','review','done')),
        priority TEXT NOT NULL DEFAULT 'medium'
          CHECK (priority IN ('low','medium','high','urgent')),
        sort_order REAL NOT NULL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE INDEX idx_tasks_status ON tasks(status);
      CREATE INDEX idx_tasks_assignee ON tasks(assignee_id);
    `,
  },
];

export const LATEST_SCHEMA_VERSION = MIGRATIONS[MIGRATIONS.length - 1].version;

export function runMigrations(): number {
  const db = getDb();
  db.exec(`CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    applied_at TEXT NOT NULL
  );`);
  const row = db.prepare('SELECT MAX(version) AS v FROM schema_migrations').get() as { v: number | null };
  const current = row.v ?? 0;
  for (const m of MIGRATIONS) {
    if (m.version <= current) continue;
    db.exec('BEGIN IMMEDIATE');
    try {
      db.exec(m.up);
      db.prepare('INSERT INTO schema_migrations (version, name, applied_at) VALUES (?, ?, ?)').run(
        m.version,
        m.name,
        nowIso(),
      );
      db.exec('COMMIT');
      console.log(`[db] migrasi ${m.version} (${m.name}) diterapkan`);
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  }
  return LATEST_SCHEMA_VERSION;
}
