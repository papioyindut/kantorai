// Lapisan data: semua akses SQL ada di sini. Route & runtime tidak menulis SQL langsung.
import { getDb, newId, nowIso, tx } from './connection';
import type {
  AIConfig,
  AppSettings,
  AvatarConfig,
  ConversationSummary,
  Desk,
  Employee,
  Message,
  MessageKind,
  MessageSender,
  Task,
  TaskPriority,
  TaskStatus,
} from '../../shared/types';
import { resolveConfigStatus, resolveActivityStatus } from '../runtime/status';

type Row = Record<string, unknown>;
const s = (v: unknown) => (v == null ? null : String(v));

function parseJson<T>(v: unknown, fallback: T): T {
  if (typeof v !== 'string' || v === '') return fallback;
  try {
    return JSON.parse(v) as T;
  } catch {
    return fallback;
  }
}

/* ----------------------------- AI config ----------------------------- */

function mapConfig(r: Row): AIConfig {
  return {
    employeeId: String(r.employee_id),
    systemPrompt: s(r.system_prompt),
    provider: s(r.provider),
    model: s(r.model),
    tools: parseJson<string[]>(r.tools, []),
    workflowId: s(r.workflow_id),
    workflowConfig: parseJson<Record<string, unknown> | null>(r.workflow_config, null),
    memoryConfig: parseJson<Record<string, unknown> | null>(r.memory_config, null),
    updatedAt: String(r.updated_at),
  };
}

export function getConfig(employeeId: string): AIConfig {
  const r = getDb().prepare('SELECT * FROM ai_configs WHERE employee_id = ?').get(employeeId) as Row | undefined;
  if (r) return mapConfig(r);
  return {
    employeeId,
    systemPrompt: null,
    provider: null,
    model: null,
    tools: [],
    workflowId: null,
    workflowConfig: null,
    memoryConfig: null,
    updatedAt: nowIso(),
  };
}

export function updateConfig(employeeId: string, patch: Partial<Omit<AIConfig, 'employeeId' | 'updatedAt'>>): AIConfig {
  const cur = getConfig(employeeId);
  const next = { ...cur, ...patch, updatedAt: nowIso() };
  getDb()
    .prepare(
      `INSERT INTO ai_configs (employee_id, system_prompt, provider, model, tools, workflow_id, workflow_config, memory_config, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
       ON CONFLICT(employee_id) DO UPDATE SET
         system_prompt = excluded.system_prompt, provider = excluded.provider, model = excluded.model,
         tools = excluded.tools, workflow_id = excluded.workflow_id, workflow_config = excluded.workflow_config,
         memory_config = excluded.memory_config, updated_at = excluded.updated_at`,
    )
    .run(
      employeeId,
      next.systemPrompt,
      next.provider,
      next.model,
      JSON.stringify(next.tools ?? []),
      next.workflowId,
      next.workflowConfig ? JSON.stringify(next.workflowConfig) : null,
      next.memoryConfig ? JSON.stringify(next.memoryConfig) : null,
      next.updatedAt,
    );
  return getConfig(employeeId);
}

/* ----------------------------- Employees ----------------------------- */

function mapEmployee(r: Row): Employee {
  const id = String(r.id);
  const config = getConfig(id);
  const configStatus = resolveConfigStatus(config);
  return {
    id,
    name: String(r.name),
    role: String(r.role),
    description: String(r.description ?? ''),
    avatar: parseJson<AvatarConfig>(r.avatar, { skin: '#f1c27d', hair: 'short', hairColor: '#3b2a20', accessory: 'none' }),
    color: String(r.color),
    deskId: s(r.desk_id),
    archived: r.archived_at != null,
    archivedAt: s(r.archived_at),
    configStatus,
    activityStatus: resolveActivityStatus(configStatus, String(r.activity_status)),
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

export function listEmployees(includeArchived = true): Employee[] {
  const sql = includeArchived
    ? 'SELECT * FROM employees ORDER BY created_at ASC'
    : 'SELECT * FROM employees WHERE archived_at IS NULL ORDER BY created_at ASC';
  return (getDb().prepare(sql).all() as Row[]).map(mapEmployee);
}

export function getEmployee(id: string): Employee | null {
  const r = getDb().prepare('SELECT * FROM employees WHERE id = ?').get(id) as Row | undefined;
  return r ? mapEmployee(r) : null;
}

export interface EmployeeRecord {
  name: string;
  role: string;
  description: string;
  avatar: AvatarConfig;
  color: string;
  deskId: string | null;
}

export function createEmployee(input: EmployeeRecord, id = newId('emp')): Employee {
  const now = nowIso();
  tx(() => {
    if (input.deskId) clearDesk(input.deskId);
    getDb()
      .prepare(
        `INSERT INTO employees (id, name, role, description, avatar, color, desk_id, activity_status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'offline', ?, ?)`,
      )
      .run(id, input.name, input.role, input.description, JSON.stringify(input.avatar), input.color, input.deskId, now, now);
    getDb()
      .prepare(`INSERT INTO ai_configs (employee_id, tools, updated_at) VALUES (?, '[]', ?)`)
      .run(id, now);
  });
  return getEmployee(id)!;
}

export function updateEmployee(id: string, patch: Partial<EmployeeRecord>): Employee {
  const cur = getEmployee(id);
  if (!cur) throw new Error('not_found');
  const next = {
    name: patch.name ?? cur.name,
    role: patch.role ?? cur.role,
    description: patch.description ?? cur.description,
    avatar: patch.avatar ?? cur.avatar,
    color: patch.color ?? cur.color,
  };
  getDb()
    .prepare('UPDATE employees SET name=?, role=?, description=?, avatar=?, color=?, updated_at=? WHERE id=?')
    .run(next.name, next.role, next.description, JSON.stringify(next.avatar), next.color, nowIso(), id);
  if (patch.deskId !== undefined) assignDesk(id, patch.deskId);
  return getEmployee(id)!;
}

export function setArchived(id: string, archived: boolean): Employee {
  tx(() => {
    if (archived) {
      // Karyawan yang diarsipkan melepaskan mejanya.
      getDb().prepare('UPDATE employees SET archived_at=?, desk_id=NULL, updated_at=? WHERE id=?').run(nowIso(), nowIso(), id);
    } else {
      getDb().prepare('UPDATE employees SET archived_at=NULL, updated_at=? WHERE id=?').run(nowIso(), id);
    }
  });
  return getEmployee(id)!;
}

/* ------------------------------- Desks ------------------------------- */

export function listDesks(): Desk[] {
  const rows = getDb()
    .prepare(
      `SELECT d.*, e.id AS employee_id FROM desks d
       LEFT JOIN employees e ON e.desk_id = d.id AND e.archived_at IS NULL
       ORDER BY d.sort_order ASC`,
    )
    .all() as Row[];
  return rows.map((r) => ({
    id: String(r.id),
    label: String(r.label),
    zone: 'work',
    x: Number(r.x),
    y: Number(r.y),
    employeeId: s(r.employee_id),
  }));
}

export function deskExists(deskId: string): boolean {
  return !!getDb().prepare('SELECT 1 FROM desks WHERE id = ?').get(deskId);
}

function clearDesk(deskId: string) {
  getDb().prepare('UPDATE employees SET desk_id=NULL, updated_at=? WHERE desk_id=?').run(nowIso(), deskId);
}

/** Menempatkan karyawan ke meja. Penghuni lama (jika ada) dipindah ke lounge (tanpa meja). */
export function assignDesk(employeeId: string, deskId: string | null): void {
  tx(() => {
    if (deskId) clearDesk(deskId);
    getDb().prepare('UPDATE employees SET desk_id=?, updated_at=? WHERE id=?').run(deskId, nowIso(), employeeId);
  });
}

export function insertDesk(d: { id: string; label: string; x: number; y: number; sortOrder: number }) {
  getDb()
    .prepare('INSERT OR IGNORE INTO desks (id, label, zone, x, y, sort_order) VALUES (?, ?, ?, ?, ?, ?)')
    .run(d.id, d.label, 'work', d.x, d.y, d.sortOrder);
}

/* --------------------------- Conversations --------------------------- */

function mapMessage(r: Row): Message {
  return {
    id: String(r.id),
    conversationId: String(r.conversation_id),
    employeeId: String(r.employee_id),
    sender: String(r.sender) as MessageSender,
    kind: String(r.kind) as MessageKind,
    content: String(r.content),
    createdAt: String(r.created_at),
  };
}

export function getOrCreateConversation(employeeId: string): string {
  const db = getDb();
  const r = db.prepare('SELECT id FROM conversations WHERE employee_id = ?').get(employeeId) as Row | undefined;
  if (r) return String(r.id);
  const id = newId('conv');
  const now = nowIso();
  db.prepare('INSERT INTO conversations (id, employee_id, created_at, updated_at) VALUES (?, ?, ?, ?)').run(id, employeeId, now, now);
  return id;
}

export function listMessages(employeeId: string, limit = 500): Message[] {
  const rows = getDb()
    .prepare(
      `SELECT * FROM (
         SELECT m.*, c.employee_id FROM messages m
         JOIN conversations c ON c.id = m.conversation_id
         WHERE c.employee_id = ?
         ORDER BY m.created_at DESC, m.rowid DESC LIMIT ?
       ) ORDER BY created_at ASC`,
    )
    .all(employeeId, limit) as Row[];
  return rows.map(mapMessage);
}

export function addMessage(employeeId: string, sender: MessageSender, kind: MessageKind, content: string): Message {
  const convId = getOrCreateConversation(employeeId);
  const id = newId('msg');
  const now = nowIso();
  const db = getDb();
  db.prepare('INSERT INTO messages (id, conversation_id, sender, kind, content, created_at) VALUES (?, ?, ?, ?, ?, ?)').run(
    id,
    convId,
    sender,
    kind,
    content,
    now,
  );
  db.prepare('UPDATE conversations SET updated_at=? WHERE id=?').run(now, convId);
  return { id, conversationId: convId, employeeId, sender, kind, content, createdAt: now };
}

export function listConversationSummaries(): ConversationSummary[] {
  const db = getDb();
  const emps = db.prepare('SELECT id FROM employees ORDER BY created_at ASC').all() as Row[];
  return emps.map((e) => {
    const employeeId = String(e.id);
    const conv = db.prepare('SELECT id, updated_at FROM conversations WHERE employee_id = ?').get(employeeId) as Row | undefined;
    if (!conv) return { id: null, employeeId, lastMessage: null, messageCount: 0, updatedAt: null };
    const last = db
      .prepare(
        `SELECT m.*, ? AS employee_id FROM messages m WHERE conversation_id = ? ORDER BY created_at DESC, rowid DESC LIMIT 1`,
      )
      .get(employeeId, conv.id as string) as Row | undefined;
    const count = db.prepare('SELECT COUNT(*) AS n FROM messages WHERE conversation_id = ?').get(conv.id as string) as Row;
    return {
      id: String(conv.id),
      employeeId,
      lastMessage: last ? mapMessage(last) : null,
      messageCount: Number(count.n),
      updatedAt: String(conv.updated_at),
    };
  });
}

/* ------------------------------- Tasks ------------------------------- */

function mapTask(r: Row): Task {
  return {
    id: String(r.id),
    title: String(r.title),
    description: String(r.description ?? ''),
    assigneeId: s(r.assignee_id),
    status: String(r.status) as TaskStatus,
    priority: String(r.priority) as TaskPriority,
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

export function listTasks(filter: { assigneeId?: string } = {}): Task[] {
  const db = getDb();
  const rows = filter.assigneeId
    ? (db.prepare('SELECT * FROM tasks WHERE assignee_id = ? ORDER BY sort_order ASC, created_at DESC').all(filter.assigneeId) as Row[])
    : (db.prepare('SELECT * FROM tasks ORDER BY sort_order ASC, created_at DESC').all() as Row[]);
  return rows.map(mapTask);
}

export function getTask(id: string): Task | null {
  const r = getDb().prepare('SELECT * FROM tasks WHERE id = ?').get(id) as Row | undefined;
  return r ? mapTask(r) : null;
}

export interface TaskRecord {
  title: string;
  description: string;
  assigneeId: string | null;
  status: TaskStatus;
  priority: TaskPriority;
}

export function createTask(input: TaskRecord): Task {
  const id = newId('task');
  const now = nowIso();
  const min = getDb().prepare('SELECT MIN(sort_order) AS m FROM tasks').get() as Row;
  const order = (min.m == null ? 0 : Number(min.m)) - 1;
  getDb()
    .prepare(
      `INSERT INTO tasks (id, title, description, assignee_id, status, priority, sort_order, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    )
    .run(id, input.title, input.description, input.assigneeId, input.status, input.priority, order, now, now);
  return getTask(id)!;
}

export function updateTask(id: string, patch: Partial<TaskRecord>): Task {
  const cur = getTask(id);
  if (!cur) throw new Error('not_found');
  const n = { ...cur, ...patch };
  getDb()
    .prepare('UPDATE tasks SET title=?, description=?, assignee_id=?, status=?, priority=?, updated_at=? WHERE id=?')
    .run(n.title, n.description, n.assigneeId, n.status, n.priority, nowIso(), id);
  return getTask(id)!;
}

export function deleteTask(id: string): boolean {
  const res = getDb().prepare('DELETE FROM tasks WHERE id = ?').run(id);
  return Number(res.changes) > 0;
}

/* ----------------------------- Settings ------------------------------ */

const DEFAULT_SETTINGS: AppSettings = { officeName: 'Kantor AI Saya', demoMode: false };

export function getSettings(): AppSettings {
  const rows = getDb().prepare('SELECT key, value FROM settings').all() as Row[];
  const out: AppSettings = { ...DEFAULT_SETTINGS };
  for (const r of rows) {
    const key = String(r.key) as keyof AppSettings;
    if (key in out) (out as unknown as Record<string, unknown>)[key] = parseJson(r.value, out[key]);
  }
  return out;
}

export function updateSettings(patch: Partial<AppSettings>): AppSettings {
  const stmt = getDb().prepare(
    'INSERT INTO settings (key, value, updated_at) VALUES (?, ?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at',
  );
  tx(() => {
    for (const [k, v] of Object.entries(patch)) {
      if (v === undefined || !(k in DEFAULT_SETTINGS)) continue;
      stmt.run(k, JSON.stringify(v), nowIso());
    }
  });
  return getSettings();
}

/* -------------------------------- Meta ------------------------------- */

export function getMeta(key: string): string | null {
  const r = getDb().prepare('SELECT value FROM meta WHERE key = ?').get(key) as Row | undefined;
  return r ? String(r.value) : null;
}

export function setMeta(key: string, value: string): void {
  getDb().prepare('INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, value);
}

export function exportAll() {
  return {
    exportedAt: nowIso(),
    settings: getSettings(),
    desks: listDesks(),
    employees: listEmployees(true).map((e) => ({ ...e, aiConfig: getConfig(e.id) })),
    conversations: listEmployees(true).map((e) => ({ employeeId: e.id, messages: listMessages(e.id, 100000) })),
    tasks: listTasks(),
  };
}
