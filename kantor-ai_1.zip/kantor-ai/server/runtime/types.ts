// ============================================================================
//  KONTRAK RUNTIME AI — titik integrasi tahap berikutnya.
//
//  - AIProviderAdapter : menghubungkan karyawan AI ke model (OpenAI, Anthropic,
//                        Ollama lokal, dll). Daftarkan di runtime/registry.ts.
//  - WorkflowEngine    : menjalankan workflow saat task ditugaskan / dipicu.
//
//  UI kantor & messenger hanya berbicara dengan RuntimeService (service.ts),
//  sehingga provider/engine baru dapat ditambahkan tanpa mengubah UI.
// ============================================================================
import type { AIConfig, Employee, Message, Task } from '../../shared/types';

export interface RuntimeContext {
  employee: Employee;
  config: AIConfig;
  /** Riwayat percakapan (urut lama → baru), sudah termasuk pesan pengguna terbaru. */
  history: Message[];
}

export interface ProviderReply {
  content: string;
  /** Metadata opsional (token, latency, dsb.) untuk tahap berikutnya. */
  meta?: Record<string, unknown>;
}

export interface AIProviderAdapter {
  /** ID unik yang disimpan di AIConfig.provider, mis. "openai", "ollama". */
  readonly id: string;
  readonly label: string;
  /** 'mock' tidak pernah membuat karyawan berstatus "siap". */
  readonly kind: 'mock' | 'provider';
  /** Validasi konfigurasi (mis. model tersedia). Kembalikan pesan error atau null. */
  validateConfig(config: AIConfig): string | null;
  /** Menghasilkan balasan untuk percakapan. */
  generateReply(ctx: RuntimeContext): Promise<ProviderReply>;
}

export interface WorkflowTrigger {
  type: 'task_assigned' | 'manual';
  task?: Task;
  employee: Employee;
  config: AIConfig;
}

export interface WorkflowRunResult {
  started: boolean;
  runId?: string;
  reason: string;
}

export interface WorkflowEngine {
  readonly id: string;
  readonly label: string;
  /** Dipanggil saat task ditugaskan ke karyawan AI atau dipicu manual. */
  trigger(input: WorkflowTrigger): Promise<WorkflowRunResult>;
}
