// RuntimeService: satu-satunya pintu antara aplikasi (route/UI) dan runtime AI.
import type { Employee, SendMessageResult, Task, TaskMutationResult } from '../../shared/types';
import * as repo from '../db/repo';
import { getProvider, getSimulationAdapter, getWorkflowEngine } from './registry';

export async function handleUserMessage(employee: Employee, content: string): Promise<SendMessageResult> {
  const userMessage = repo.addMessage(employee.id, 'user', 'normal', content);
  const config = repo.getConfig(employee.id);
  const settings = repo.getSettings();
  const history = repo.listMessages(employee.id, 50);

  // 1) Provider sungguhan (belum ada pada tahap ini).
  if (employee.configStatus === 'ready') {
    const adapter = getProvider(config.provider)!;
    try {
      const out = await adapter.generateReply({ employee, config, history });
      const reply = repo.addMessage(employee.id, 'ai', 'normal', out.content);
      return { userMessage, reply, notice: null, replySource: 'provider' };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return { userMessage, reply: null, notice: `Runtime AI gagal membalas: ${msg}`, replySource: 'none' };
    }
  }

  // 2) Mode demo: balasan simulasi, disimpan dan diberi label "Simulasi".
  if (settings.demoMode) {
    const out = await getSimulationAdapter().generateReply({ employee, config, history });
    const reply = repo.addMessage(employee.id, 'ai', 'simulation', out.content);
    return { userMessage, reply, notice: null, replySource: 'simulation' };
  }

  // 3) Tidak ada runtime: pesan disimpan, tidak ada balasan.
  return {
    userMessage,
    reply: null,
    notice: `${employee.name} belum dikonfigurasi. Pesan disimpan, tetapi belum ada model AI yang membalas.`,
    replySource: 'none',
  };
}

/** Hook saat task dibuat/ditugaskan ulang. Tahap ini: engine no-op, tidak menjalankan apa pun. */
export async function onTaskAssigned(task: Task, previousAssigneeId: string | null): Promise<TaskMutationResult> {
  if (!task.assigneeId || task.assigneeId === previousAssigneeId) return { task, workflow: null };
  const employee = repo.getEmployee(task.assigneeId);
  if (!employee) return { task, workflow: null };
  const config = repo.getConfig(employee.id);
  const workflow = await getWorkflowEngine(config.workflowId).trigger({ type: 'task_assigned', task, employee, config });
  return { task, workflow: { started: workflow.started, reason: workflow.reason } };
}
