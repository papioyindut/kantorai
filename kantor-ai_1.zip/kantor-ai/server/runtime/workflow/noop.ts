import type { WorkflowEngine } from '../types';

/**
 * Engine kosong. Tahap ini TIDAK menjalankan workflow apa pun:
 * menugaskan task ke AI hanya mencatat penugasan.
 * Ganti/tambah engine sungguhan di runtime/registry.ts.
 */
export const noopWorkflowEngine: WorkflowEngine = {
  id: 'none',
  label: 'Belum ada workflow engine',
  async trigger({ config }) {
    return {
      started: false,
      reason: config.workflowId
        ? 'Workflow engine belum tersedia pada tahap ini.'
        : 'Workflow belum disetup untuk karyawan ini. Task dicatat dan dikelola manual.',
    };
  },
};
