import type { AIProviderAdapter, RuntimeContext } from '../types';

/**
 * Adapter mock untuk MODE DEMO. Balasannya selalu disimpan dengan kind='simulation'
 * dan ditampilkan berlabel "Simulasi" — bukan keluaran model AI.
 * Tidak ada panggilan jaringan; tidak butuh API key.
 */
export const simulationAdapter: AIProviderAdapter = {
  id: 'simulation',
  label: 'Simulasi (mode demo)',
  kind: 'mock',
  validateConfig: () => null,
  async generateReply({ employee, history }: RuntimeContext) {
    const last = [...history].reverse().find((m) => m.sender === 'user');
    const quote = last ? last.content.trim().replace(/\s+/g, ' ') : '';
    const short = quote.length > 80 ? `${quote.slice(0, 77)}…` : quote;
    const templates = [
      `Halo, saya ${employee.name} (${employee.role}). Ini balasan simulasi — saya belum terhubung ke model AI, jadi belum benar-benar memproses “${short}”.`,
      `Pesan “${short}” sudah tercatat. Setelah runtime AI untuk ${employee.name} dikonfigurasi, balasan sungguhan akan muncul di sini.`,
      `[Demo] ${employee.name} menerima pesan Anda. Workflow dan model belum disetup, jadi balasan ini hanya contoh tampilan.`,
    ];
    const userCount = history.filter((m) => m.sender === 'user').length;
    return { content: templates[(userCount - 1 + templates.length) % templates.length] };
  },
};
