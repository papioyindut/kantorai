import type { AIProviderAdapter, WorkflowEngine } from './types';
import { simulationAdapter } from './adapters/simulation';
import { noopWorkflowEngine } from './workflow/noop';

// ---------------------------------------------------------------------------
//  TITIK INTEGRASI: daftarkan provider & workflow engine sungguhan di sini.
//
//    import { openAIAdapter } from './adapters/openai';
//    registerProvider(openAIAdapter);
//
//  Setelah terdaftar, karyawan dengan AIConfig.provider = adapter.id dan
//  model terisi otomatis berstatus "siap" dan pesan diteruskan ke adapter.
// ---------------------------------------------------------------------------

const providers = new Map<string, AIProviderAdapter>();
const engines = new Map<string, WorkflowEngine>();
let defaultEngineId = noopWorkflowEngine.id;

export function registerProvider(adapter: AIProviderAdapter): void {
  providers.set(adapter.id, adapter);
}

export function registerWorkflowEngine(engine: WorkflowEngine, makeDefault = false): void {
  engines.set(engine.id, engine);
  if (makeDefault) defaultEngineId = engine.id;
}

export function getProvider(id: string | null | undefined): AIProviderAdapter | undefined {
  return id ? providers.get(id) : undefined;
}

export function getSimulationAdapter(): AIProviderAdapter {
  return simulationAdapter;
}

export function getWorkflowEngine(id?: string | null): WorkflowEngine {
  return (id && engines.get(id)) || engines.get(defaultEngineId) || noopWorkflowEngine;
}

export function listProviders(): AIProviderAdapter[] {
  return [...providers.values()];
}

export function listWorkflowEngines(): WorkflowEngine[] {
  return [...engines.values()];
}

// Registrasi bawaan tahap ini: hanya mock & no-op.
registerProvider(simulationAdapter);
registerWorkflowEngine(noopWorkflowEngine, true);
