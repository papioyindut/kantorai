import type { ActivityStatus, AIConfig, ConfigStatus } from '../../shared/types';
import { getProvider } from './registry';

/**
 * "Siap" hanya bila provider sungguhan terdaftar, model terisi, dan konfigurasi valid.
 * Adapter mock (simulasi) tidak pernah membuat karyawan "siap".
 */
export function resolveConfigStatus(config: AIConfig): ConfigStatus {
  const adapter = getProvider(config.provider);
  if (!adapter || adapter.kind === 'mock') return 'unconfigured';
  if (!config.model || !config.model.trim()) return 'unconfigured';
  return adapter.validateConfig(config) ? 'unconfigured' : 'ready';
}

/** AI tanpa runtime terhubung tidak boleh terlihat sedang bekerja. */
export function resolveActivityStatus(configStatus: ConfigStatus, stored: string): ActivityStatus {
  if (configStatus !== 'ready') return 'offline';
  const allowed: ActivityStatus[] = ['idle', 'working', 'waiting', 'error', 'offline'];
  return (allowed as string[]).includes(stored) ? (stored as ActivityStatus) : 'idle';
}
