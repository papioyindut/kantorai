// Menjalankan backend (tsx watch) dan frontend (vite) dengan satu perintah: `npm run dev`.
// Tanpa dependensi tambahan agar tetap ringan dan lintas-platform.
import { spawn } from 'node:child_process';

const [major, minor] = process.versions.node.split('.').map(Number);
if (major < 22 || (major === 22 && minor < 13)) {
  console.error(`\n[kantor-ai] Butuh Node.js >= 22.13 (terpasang: ${process.versions.node}).\n`);
  process.exit(1);
}

const procs = [];
const colors = { server: '\x1b[36m', web: '\x1b[35m' };
const reset = '\x1b[0m';

function run(name, script) {
  const child = spawn('npm', ['run', script, '--silent'], {
    stdio: ['inherit', 'pipe', 'pipe'],
    shell: process.platform === 'win32',
    env: { ...process.env, FORCE_COLOR: '1' },
  });
  const prefix = `${colors[name]}[${name}]${reset} `;
  const pipe = (stream, out) => {
    let buf = '';
    stream.on('data', (d) => {
      buf += d.toString();
      const lines = buf.split('\n');
      buf = lines.pop() ?? '';
      for (const l of lines) out.write(prefix + l + '\n');
    });
  };
  pipe(child.stdout, process.stdout);
  pipe(child.stderr, process.stderr);
  child.on('exit', (code) => {
    console.log(`${prefix}berhenti (kode ${code}).`);
    shutdown(code ?? 0);
  });
  procs.push(child);
}

let stopping = false;
function shutdown(code) {
  if (stopping) return;
  stopping = true;
  for (const p of procs) if (!p.killed) p.kill('SIGTERM');
  setTimeout(() => process.exit(code), 300);
}
process.on('SIGINT', () => shutdown(0));
process.on('SIGTERM', () => shutdown(0));

run('server', 'dev:server');
run('web', 'dev:web');
