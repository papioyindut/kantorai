// Uji cepat API + persistensi: `npm run test:api`
// Menjalankan server dua kali pada folder data sementara, lalu memeriksa data tetap ada.
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';

const dir = mkdtempSync(path.join(tmpdir(), 'kantor-ai-test-'));
const PORT = 5299;
const B = `http://127.0.0.1:${PORT}/api`;
let failed = 0;
const check = (name, cond) => {
  console.log(`${cond ? '✔' : '✘'} ${name}`);
  if (!cond) failed++;
};

function start() {
  const p = spawn(process.execPath, ['--import', 'tsx', 'server/index.ts'], {
    env: { ...process.env, VO_DATA_DIR: dir, VO_PORT: String(PORT) },
    stdio: 'ignore',
  });
  return p;
}
async function waitUp() {
  for (let i = 0; i < 50; i++) {
    try {
      if ((await fetch(`${B}/health`)).ok) return;
    } catch {}
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new Error('Server tidak menyala');
}
const j = async (method, url, body) => {
  const r = await fetch(B + url, { method, headers: { 'content-type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, data: await r.json() };
};
const stop = (p) => new Promise((r) => { p.once('exit', r); p.kill('SIGTERM'); });

try {
  let srv = start();
  await waitUp();
  const emps = (await j('GET', '/employees')).data;
  check('Seed 5 karyawan contoh', emps.length === 5);
  check('Semua belum dikonfigurasi & offline', emps.every((e) => e.configStatus === 'unconfigured' && e.activityStatus === 'offline'));
  const created = await j('POST', '/employees', { name: 'Uji', role: 'Tester', deskId: 'desk-12' });
  check('Tambah karyawan', created.status === 201 && created.data.deskId === 'desk-12');
  check('Validasi nama kosong', (await j('POST', '/employees', { name: '', role: 'x' })).status === 422);
  await j('PATCH', `/employees/${emps[0].id}`, { name: 'Diubah' });
  const msg = await j('POST', `/employees/${emps[1].id}/messages`, { content: 'halo' });
  check('Pesan tersimpan tanpa balasan (belum dikonfigurasi)', msg.status === 201 && msg.data.reply === null);
  const task = await j('POST', '/tasks', { title: 'T', assigneeId: created.data.id, priority: 'high' });
  check('Task dibuat; workflow tidak berjalan', task.data.workflow?.started === false);
  await stop(srv);

  srv = start();
  await waitUp();
  const after = (await j('GET', '/employees')).data;
  check('Restart: seed tidak dobel', after.length === 6);
  check('Restart: edit bertahan', after.some((e) => e.name === 'Diubah'));
  check('Restart: meja bertahan', after.find((e) => e.name === 'Uji')?.deskId === 'desk-12');
  check('Restart: pesan pada percakapan yang benar', (await j('GET', `/employees/${emps[1].id}/messages`)).data.length === 1 && (await j('GET', `/employees/${emps[2].id}/messages`)).data.length === 0);
  check('Restart: task bertahan', (await j('GET', '/tasks')).data.some((t) => t.title === 'T'));
  await stop(srv);
} catch (e) {
  console.error(e);
  failed++;
} finally {
  rmSync(dir, { recursive: true, force: true });
}
console.log(failed ? `\n${failed} pemeriksaan gagal` : '\nSemua pemeriksaan lulus');
process.exit(failed ? 1 : 0);
