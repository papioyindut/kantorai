# Kantor AI — MVP Tahap 1

Kantor virtual lokal berisi karyawan AI: kantor pixel art 2D, manajemen karyawan, messenger per AI, dan task board. Berjalan sepenuhnya di komputer Anda via `localhost`, **tanpa API key dan tanpa layanan eksternal**.

> Tahap ini membangun kantor, antarmuka, penyimpanan, dan fondasi sistem. Model AI, instruksi kerja, tools, dan workflow **belum** disetup. Semua karyawan berstatus *Belum dikonfigurasi* dan tampil *Offline*.

## Kebutuhan

- **Node.js ≥ 22.13** (memakai modul SQLite bawaan Node, `node:sqlite`, jadi tidak perlu kompilasi modul native)
- npm

Node 22 mungkin menampilkan peringatan `ExperimentalWarning: SQLite is an experimental feature`. Peringatan ini normal dan aman diabaikan.

## Instalasi & menjalankan

```bash
npm install
npm run dev
```

Buka **http://localhost:5173**. `npm run dev` menjalankan backend (API, port 5174) dan frontend (Vite, port 5173) sekaligus. Hentikan dengan `Ctrl+C`.

Mode produksi lokal (satu port, tanpa Vite dev server):

```bash
npm run build
npm start          # buka http://127.0.0.1:5174
```

Perintah lain:

| Perintah | Fungsi |
|---|---|
| `npm run typecheck` | Pemeriksaan TypeScript frontend + backend |
| `npm run test:api` | Uji cepat API & persistensi (menyalakan server 2× pada folder data sementara) |

## Lokasi penyimpanan data

- Database SQLite: **`./data/virtual-office.db`** (di dalam folder proyek). File `-wal`/`-shm` di sebelahnya adalah bagian dari mode WAL SQLite.
- Ubah lokasi dengan variabel lingkungan `VO_DATA_DIR`, mis. `VO_DATA_DIR=~/kantor-data npm run dev`.
- Lokasi aktif juga terlihat di halaman **Settings → Penyimpanan lokal**, dan data bisa diekspor sebagai JSON dari halaman yang sama.
- Cadangan: salin file database saat aplikasi tidak berjalan. Reset total: hapus folder `data/` lalu jalankan ulang, dan data contoh akan dibuat lagi.

Keamanan jaringan: server hanya mendengarkan `127.0.0.1` secara default (env `VO_HOST`/`VO_PORT` untuk mengubah). Vite juga hanya di `localhost`.

## Fitur yang berfungsi

- **Office (halaman utama):** kantor top-down pixel art buatan sendiri (SVG) dengan area kerja (12 meja), ruang meeting, dan area santai. Ada avatar, label nama/jabatan, indikator status, serta animasi ringan: napas, kedip, awan di jendela, uap kopi, tanaman, dan jam dinding sesuai waktu nyata. Animasi mati otomatis bila sistem meminta *reduce motion*.
  - Klik avatar → kartu karyawan → **Profil** atau **Chat**.
  - **Atur meja:** klik meja untuk menempatkan, memindah, atau mengosongkan. Klik karyawan di area santai untuk memilihkan meja. Posisi tersimpan otomatis. Karyawan tanpa meja berdiri di area santai.
- **Employees:** tambah, edit (nama, jabatan, deskripsi, avatar pixel yang bisa diatur — kulit, rambut, warna rambut, aksesori — warna identitas, meja), arsipkan, aktifkan kembali, cari, dan filter.
- **Profil karyawan** (drawer, dari kantor atau daftar): tab **Overview · Chat · Tasks · Workflow · Settings**.
  - Workflow menampilkan “Workflow belum disetup”.
  - Settings menampilkan struktur konfigurasi AI (kosong, dinonaktifkan), edit profil, dan arsip.
- **Status terpisah:** *konfigurasi* (belum dikonfigurasi / siap) dan *aktivitas* (idle / working / waiting / error / offline). AI tanpa runtime selalu *Offline* — diterapkan di backend (`server/runtime/status.ts`), bukan hanya di UI.
- **Messages:** percakapan per AI, tersimpan di SQLite, dengan pratinjau pesan terakhir. Tanpa runtime, pesan disimpan dan muncul pemberitahuan “belum dikonfigurasi”.
- **Mode demo** (Settings, default mati): balasan template lokal yang disimpan dengan `kind = 'simulation'` dan selalu ditampilkan berlabel **“Simulasi · bukan model AI”**.
- **Tasks:** kanban Backlog / To Do / Dikerjakan / Review / Selesai. Ada drag & drop, detail & edit, prioritas, penugasan, waktu dibuat, hapus dengan konfirmasi, serta filter karyawan/prioritas. UI menjelaskan bahwa penugasan belum menjalankan workflow.
- Empty state, skeleton loading, validasi form (frontend + backend), dan pesan error/toast berbahasa Indonesia.

## Struktur proyek

```
shared/            Tipe domain & tata letak kantor (dipakai FE + BE)
server/
  index.ts         HTTP server (127.0.0.1), static dist untuk `npm start`
  routes.ts        REST API (/api/...)
  http.ts          Router minimal tanpa dependensi
  validate.ts      Validasi input
  db/              connection · migrations · repo (semua SQL) · seed (sekali)
  runtime/         ← lapisan runtime AI (terpisah dari UI & data)
    types.ts       Kontrak AIProviderAdapter & WorkflowEngine
    registry.ts    Registrasi provider/engine
    service.ts     RuntimeService: pintu tunggal UI ↔ runtime
    status.ts      Aturan status konfigurasi & aktivitas
    adapters/simulation.ts   Adapter mock (mode demo)
    workflow/noop.ts         Workflow engine kosong
src/
  api/client.ts    Klien API
  state/           DataContext (karyawan, meja, pengaturan, toast)
  components/      office (scene + sprite), employees, chat, tasks, ui
  pages/           Office, Employees, Messages, Tasks, Settings
```

## Model data (SQLite)

`employees`, `desks`, `ai_configs` (`system_prompt`, `provider`, `model`, `tools`, `workflow_id`, `workflow_config`, `memory_config` — semuanya boleh kosong), `conversations` (satu per karyawan), `messages` (`sender`, `kind`: normal/simulation/notice), `tasks`, `settings`, `meta` (`seeded_at`), dan `schema_migrations`. ID stabil berprefix (`emp_…`, `task_…`), timestamp ISO.

- **Migrasi** berversi ada di `server/db/migrations.ts`. Tambah versi baru, jangan ubah yang lama.
- **Seed** hanya berjalan sekali (dijaga `meta.seeded_at`), jadi perubahan Anda tidak tertimpa saat restart.

## Titik integrasi tahap berikutnya

1. **Provider model AI** — buat adapter yang mengimplementasikan `AIProviderAdapter` (`server/runtime/types.ts`), lalu daftarkan di `server/runtime/registry.ts`:
   ```ts
   registerProvider(myOllamaAdapter); // kind: 'provider'
   ```
   Karyawan dengan `ai_configs.provider = adapter.id` dan `model` terisi otomatis berstatus **Siap**. `RuntimeService.handleUserMessage` (`server/runtime/service.ts`) lalu meneruskan pesan ke `adapter.generateReply()` dan menyimpan balasan sebagai `kind = 'normal'`. Messenger tidak perlu diubah.
2. **Workflow engine** — implementasikan `WorkflowEngine.trigger()` dan daftarkan dengan `registerWorkflowEngine(engine, true)`. Hook `onTaskAssigned` di `service.ts` sudah dipanggil setiap kali task dibuat atau ditugaskan ulang (`POST/PATCH /api/tasks`).
3. **Konfigurasi per karyawan** — API sudah tersedia: `GET/PATCH /api/employees/:id/config`. Form di tab **Settings** profil (`src/components/employees/EmployeeProfile.tsx`, `SettingsTab`) tinggal diaktifkan. Tab **Workflow** (`WorkflowTab`) adalah tempat UI setup workflow.
4. **Status aktivitas** — kolom `employees.activity_status` disiapkan untuk diperbarui runtime (idle/working/waiting/error). Kantor sudah punya visual untuk tiap status (LED monitor, animasi mengetik, gelembung “…” dan “!”).

## Batas tahap ini

Belum ada workflow otomatis, kolaborasi antar-AI, akses terminal/file, integrasi API model atau aplikasi eksternal, cloud sync, multi-user, maupun autentikasi. Kontrol untuk fitur mendatang diberi label **Tahap berikutnya** dan dinonaktifkan.

Semua aset visual (kantor, karakter, ikon, logo) digambar khusus untuk proyek ini.
