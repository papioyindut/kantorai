// Tata letak peta kantor (unit SVG). Dipakai server (seed meja) & frontend (render).
export const TILE = 16;
export const MAP_W = 768; // 48 tile
export const MAP_H = 448; // 28 tile
export const WALL_H = 48;

export const ZONES = {
  work: { x: 0, y: WALL_H, w: 496, h: MAP_H - WALL_H, label: 'Area Kerja' },
  meeting: { x: 504, y: WALL_H, w: MAP_W - 504, h: 176, label: 'Ruang Meeting' },
  lounge: { x: 504, y: WALL_H + 184, w: MAP_W - 504, h: MAP_H - WALL_H - 184, label: 'Area Santai' },
} as const;

/** Slot meja: 3 baris × 4 kolom. (x, y) = titik tengah atas permukaan meja. */
export const DESK_SLOTS: { id: string; label: string; x: number; y: number }[] = (() => {
  const cols = [72, 186, 300, 414];
  const rows = [128, 246, 364];
  const out: { id: string; label: string; x: number; y: number }[] = [];
  let n = 1;
  for (const y of rows)
    for (const x of cols) {
      out.push({ id: `desk-${String(n).padStart(2, '0')}`, label: `Meja ${n}`, x, y });
      n++;
    }
  return out;
})();

/** Titik berdiri untuk karyawan tanpa meja (area santai). */
export const LOUNGE_SPOTS: { x: number; y: number }[] = [
  { x: 556, y: 324 },
  { x: 716, y: 324 },
  { x: 556, y: 398 },
  { x: 716, y: 398 },
  { x: 604, y: 420 },
  { x: 668, y: 420 },
  { x: 636, y: 322 },
  { x: 742, y: 362 },
];
