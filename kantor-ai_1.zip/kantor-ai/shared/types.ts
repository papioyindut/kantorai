// Tipe domain yang dipakai bersama oleh frontend dan backend.

export type ConfigStatus = 'unconfigured' | 'ready';
export type ActivityStatus = 'idle' | 'working' | 'waiting' | 'error' | 'offline';

export type HairStyle = 'short' | 'bob' | 'spiky' | 'long' | 'bun' | 'bald';
export type Accessory = 'none' | 'glasses' | 'headset' | 'cap';

export interface AvatarConfig {
  skin: string; // hex
  hair: HairStyle;
  hairColor: string; // hex
  accessory: Accessory;
}

export interface Employee {
  id: string;
  name: string;
  role: string;
  description: string;
  avatar: AvatarConfig;
  color: string; // warna identitas (hex)
  deskId: string | null;
  archived: boolean;
  archivedAt: string | null;
  /** Status konfigurasi: diturunkan dari AIConfig (provider + model + adapter terdaftar). */
  configStatus: ConfigStatus;
  /** Status aktivitas efektif. Selalu 'offline' bila runtime belum terhubung. */
  activityStatus: ActivityStatus;
  createdAt: string;
  updatedAt: string;
}

export interface EmployeeInput {
  name: string;
  role: string;
  description?: string;
  avatar?: AvatarConfig;
  color?: string;
  deskId?: string | null;
}

export type DeskZone = 'work';

export interface Desk {
  id: string;
  label: string;
  zone: DeskZone;
  x: number; // koordinat peta (unit SVG)
  y: number;
  employeeId: string | null;
}

/** Konfigurasi integrasi untuk tahap berikutnya. Semua boleh kosong. */
export interface AIConfig {
  employeeId: string;
  systemPrompt: string | null;
  provider: string | null;
  model: string | null;
  tools: string[];
  workflowId: string | null;
  workflowConfig: Record<string, unknown> | null;
  memoryConfig: Record<string, unknown> | null;
  updatedAt: string;
}

export type MessageSender = 'user' | 'ai' | 'system';
/** 'simulation' = balasan mode demo, BUKAN dari model AI sungguhan. */
export type MessageKind = 'normal' | 'simulation' | 'notice';

export interface Message {
  id: string;
  conversationId: string;
  employeeId: string;
  sender: MessageSender;
  kind: MessageKind;
  content: string;
  createdAt: string;
}

export interface ConversationSummary {
  id: string | null;
  employeeId: string;
  lastMessage: Message | null;
  messageCount: number;
  updatedAt: string | null;
}

export interface SendMessageResult {
  userMessage: Message;
  reply: Message | null;
  /** Penjelasan bila tidak ada balasan (mis. AI belum dikonfigurasi). */
  notice: string | null;
  replySource: 'provider' | 'simulation' | 'none';
}

export type TaskStatus = 'backlog' | 'todo' | 'in_progress' | 'review' | 'done';
export type TaskPriority = 'low' | 'medium' | 'high' | 'urgent';

export interface Task {
  id: string;
  title: string;
  description: string;
  assigneeId: string | null;
  status: TaskStatus;
  priority: TaskPriority;
  createdAt: string;
  updatedAt: string;
}

export interface TaskInput {
  title: string;
  description?: string;
  assigneeId?: string | null;
  status?: TaskStatus;
  priority?: TaskPriority;
}

export interface TaskMutationResult {
  task: Task;
  /** Hasil hook workflow saat task ditugaskan. Pada tahap ini selalu tidak berjalan. */
  workflow: { started: boolean; reason: string } | null;
}

export interface AppSettings {
  officeName: string;
  demoMode: boolean;
}

export interface SystemInfo {
  version: string;
  dbPath: string;
  dataDir: string;
  schemaVersion: number;
  seededAt: string | null;
  nodeVersion: string;
  host: string;
  port: number;
  providers: { id: string; label: string; kind: 'mock' | 'provider' }[];
  workflowEngines: { id: string; label: string }[];
}

export const TASK_STATUSES: TaskStatus[] = ['backlog', 'todo', 'in_progress', 'review', 'done'];
export const TASK_PRIORITIES: TaskPriority[] = ['low', 'medium', 'high', 'urgent'];
export const ACTIVITY_STATUSES: ActivityStatus[] = ['idle', 'working', 'waiting', 'error', 'offline'];
export const HAIR_STYLES: HairStyle[] = ['short', 'bob', 'spiky', 'long', 'bun', 'bald'];
export const ACCESSORIES: Accessory[] = ['none', 'glasses', 'headset', 'cap'];

export const LIMITS = {
  name: 40,
  role: 40,
  description: 500,
  taskTitle: 120,
  taskDescription: 4000,
  message: 4000,
  officeName: 40,
} as const;
